import torch
import torch.nn as nn
import torch.nn.functional as F
import os


def infer_feature_dim_from_projection_ckpt(checkpoint_path):
    """
    Infer the semantic feature dimension from the first projection layer.
    """
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    state_dict = checkpoint.get("model_state_dict", checkpoint)
    weight = state_dict["0.weight"]
    return int(weight.shape[1])


def build_distiller_from_ckpt(semantic_ckpt, anchor_path=None, device="cuda", clip_dim=512):
    """
    Build a SemanticDistiller whose input dimension matches the checkpoint.
    """
    feature_dim = infer_feature_dim_from_projection_ckpt(semantic_ckpt)
    distiller = SemanticDistiller(feature_dim=feature_dim, clip_dim=clip_dim).to(device)
    if anchor_path is not None:
        distiller.load_anchors(anchor_path)
    distiller.load_projection_layer(semantic_ckpt)
    distiller.projection.eval()
    return distiller

class SemanticDistiller(nn.Module):
    """
    语义蒸馏模块：将 16 维语义特征投影到 512 维 CLIP 空间，
    并计算与语义锚点的蒸馏损失。
    """
    
    def __init__(self, feature_dim=16, clip_dim=512, base_lr=0.001):
        super().__init__()
        self.feature_dim = feature_dim
        self.clip_dim = clip_dim
        self.base_lr = base_lr
        self.has_anchors = False
        self.anchors = None
        self.use_sparse_anchor_ids = False
        self.valid_anchor_ids = []
        self.valid_anchor_ids_t = None
        self.anchor_dense_to_compact = None
        
        # --- 维度桥接层 (d维 -> 512维) ---
        self.projection = nn.Sequential(
            nn.Linear(feature_dim, 128),
            nn.ReLU(),
            nn.Linear(128, clip_dim)
        )
        self.optimizer = torch.optim.Adam(self.projection.parameters(), lr=base_lr)

    def load_anchors(self, path):
        """
        加载预计算的语义锚点
        
        Args:
            path (str): 锚点文件路径 (semantic_anchors.pt)
                       格式: dict {track_id: [512]} 或 tensor [num_objects, 512]
        """
        data = torch.load(path)
        self.use_sparse_anchor_ids = False

        # 如果是字典，转换为张量
        if isinstance(data, dict):
            # 找到最大 ID
            max_id = max(data.keys()) + 1
            anchors_tensor = torch.zeros((max_id, self.clip_dim), device='cuda')
            self.valid_anchor_ids = sorted(int(track_id) for track_id in data.keys())
            self.use_sparse_anchor_ids = (
                len(self.valid_anchor_ids) != max_id
                or self.valid_anchor_ids != list(range(max_id))
            )
            for track_id, anchor_vec in data.items():
                anchors_tensor[track_id] = anchor_vec.cuda() if not anchor_vec.is_cuda else anchor_vec
            self.anchors = anchors_tensor
        else:
            self.anchors = data.cuda() if not data.is_cuda else data
            self.valid_anchor_ids = list(range(self.anchors.shape[0]))

        if self.use_sparse_anchor_ids:
            self.valid_anchor_ids_t = torch.tensor(self.valid_anchor_ids, device='cuda', dtype=torch.long)
            self.anchor_dense_to_compact = torch.full(
                (self.anchors.shape[0],), -1, device='cuda', dtype=torch.long
            )
            self.anchor_dense_to_compact[self.valid_anchor_ids_t] = torch.arange(
                len(self.valid_anchor_ids), device='cuda', dtype=torch.long
            )
        else:
            self.valid_anchor_ids_t = torch.arange(self.anchors.shape[0], device='cuda', dtype=torch.long)
            self.anchor_dense_to_compact = torch.arange(self.anchors.shape[0], device='cuda', dtype=torch.long)

        self.has_anchors = True
        print(
            f"Loaded semantic anchors: shape {self.anchors.shape}, "
            f"valid_ids={len(self.valid_anchor_ids)}, "
            f"sparse_mode={self.use_sparse_anchor_ids}"
        )

    def get_valid_anchor_ids_tensor(self):
        return self.valid_anchor_ids_t

    def get_valid_anchors(self):
        return self.anchors[self.valid_anchor_ids_t]

    def project(self, feat_16d):
        """
        投影 d 维语义特征到 512 维 CLIP 空间
        
        Args:
            feat_16d (torch.Tensor): 渲染的语义特征 [d, H, W]
            
        Returns:
            torch.Tensor: 投影后的特征 [512, H, W]
        """
        C, H, W = feat_16d.shape
        feat_flat = feat_16d.permute(1, 2, 0).reshape(-1, C)  # [H*W, 16]
        projected = self.projection(feat_flat)                 # [H*W, 512]
        return projected.reshape(H, W, self.clip_dim).permute(2, 0, 1)  # [512, H, W]

    def get_target_anchors(self, deva_mask):
        """
        根据 DEVA 掩码获取目标锚点
        
        Args:
            deva_mask (torch.Tensor): DEVA 跟踪掩码 [H, W]，值为 track_id (0-255)
            
        Returns:
            torch.Tensor: 目标锚点 [512, H, W]
        """
        H, W = deva_mask.shape
        ids = deva_mask.flatten().long()  # [H*W]
        
        # 将超出范围的 ID 裁剪到 [0, num_anchors-1]，未知 ID 映射到 zero anchor
        ids = ids.clamp(0, self.anchors.shape[0] - 1)
        
        # 索引锚点
        target = self.anchors[ids]  # [H*W, 512]
        return target.reshape(H, W, self.clip_dim).permute(2, 0, 1)  # [512, H, W]

    def compute_distillation_loss(self, pred, target, weight=None):
        """
        计算组合蒸馏损失：L2 范数 + Cosine 相似度 (Eq. sad_loss)

        公式: L_sad = mean_over_pixels[ ||pred - target||_2 + 0.5*(1 - cos_sim(pred, target)) ]
        注意：使用 L2 范数（非平方），λ_cos = 0.5 固定值。
        
        Args:
            pred (torch.Tensor): 投影的语义特征 [512, H, W]
            target (torch.Tensor): 目标锚点 [512, H, W]
            weight (torch.Tensor, optional): 权重掩码 [H, W]，用于 GSFL 一致性加权
            
        Returns:
            torch.Tensor: 蒸馏损失 (标量)
        """
        # 1. L2 距离损失
        l2_loss = torch.norm(pred - target, dim=0)  # [H, W]
        
        # 2. Cosine 相似度损失
        cos_sim = F.cosine_similarity(pred, target, dim=0)  # [H, W]
        cos_loss = 1.0 - cos_sim
        
        # 3. 组合损失
        combined_loss = l2_loss + 0.5 * cos_loss  # [H, W]
        
        # 4. 应用权重（GSFL 一致性分数）
        if weight is not None:
            combined_loss = combined_loss * weight
        
        # 返回平均损失
        return combined_loss.mean()

    def update_learning_rate(self, iteration, warmup_iters=5000, max_iters=50000):
        """
        投影层的学习率衰减
        
        策略：
        - 前 warmup_iters 保持基础学习率
        - 之后进行指数衰减：lr = base_lr * 0.1^((iter-warmup) / max_iters)
        
        Args:
            iteration (int): 当前迭代次数
            warmup_iters (int): 预热轮数
            max_iters (int): 总轮数
        """
        if iteration > warmup_iters:
            decay_factor = 0.1 ** ((iteration - warmup_iters) / max_iters)
            lr = self.base_lr * max(decay_factor, 0.0001)  # 最小学习率下界
        else:
            lr = self.base_lr
        
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = lr

    def save_projection_layer(self, save_dir, iteration):
        """
        保存投影层权重和优化器状态
        
        Args:
            save_dir (str): 保存目录
            iteration (int): 当前迭代次数
        """
        os.makedirs(save_dir, exist_ok=True)
        checkpoint_path = os.path.join(save_dir, f"semantic_distiller_{iteration}.pth")
        
        torch.save({
            'iteration': iteration,
            'model_state_dict': self.projection.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, checkpoint_path)
        print(f"Saved projection layer checkpoint: {checkpoint_path}")

    def load_projection_layer(self, checkpoint_path):
        """
        加载投影层权重和优化器状态
        
        Args:
            checkpoint_path (str): checkpoint 文件路径
            
        Returns:
            int: 加载时的迭代次数
        """
        checkpoint = torch.load(checkpoint_path)
        self.projection.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        iteration = checkpoint.get('iteration', 0)
        print(f"Loaded projection layer from {checkpoint_path} (iteration {iteration})")
        return iteration


def compute_gsfl_consistency(
    projected_feat,
    target_anchors,
    depth,
    lambda_depth=0.1,
    semantic_floor=0.2,
):
    """
    GSFL 一致性评分：结合语义相似度和深度几何一致性
    
    论文公式：
    C_uv = sim(S'_uv, T_uv) * exp(-λ * |∇Depth_uv|)
    
    Args:
        projected_feat (torch.Tensor): 投影的语义特征 [512, H, W]
        target_anchors (torch.Tensor): 目标锚点 [512, H, W]
        depth (torch.Tensor): 渲染深度图 [1, H, W] 或 [H, W]
        lambda_depth (float): 深度梯度权重系数
        
    Returns:
        torch.Tensor: 一致性分数 [H, W]，范围 [0, 1]
    """
    
    # 1. 计算语义相似度
    semantic_sim = F.cosine_similarity(projected_feat, target_anchors, dim=0)  # [H, W]
    # Keep a non-zero floor to avoid SAD gradients collapsing when cosine is mostly negative.
    semantic_sim = (semantic_sim + 1.0) * 0.5  # map [-1,1] -> [0,1]
    semantic_sim = torch.clamp(semantic_sim, min=semantic_floor, max=1.0)
    
    # 2. 处理深度图维度
    if len(depth.shape) == 3:
        depth = depth.squeeze(0)  # [H, W]
    
    # 3. 计算深度梯度（边界检测）
    # 使用 Sobel-like 算子检测深度不连续性
    depth_grad_x = torch.abs(depth[:, :-1] - depth[:, 1:])  # [H, W-1]
    depth_grad_y = torch.abs(depth[:-1, :] - depth[1:, :])  # [H-1, W]
    
    # 4. 合并梯度（补充到全分辨率）
    depth_grad_x_padded = F.pad(depth_grad_x, (0, 1, 0, 0), mode='constant', value=0)  # [H, W]
    depth_grad_y_padded = F.pad(depth_grad_y, (0, 0, 0, 1), mode='constant', value=0)  # [H, W]
    depth_grad = depth_grad_x_padded + depth_grad_y_padded  # [H, W]
    
    # 5. 将深度梯度转换为权重
    # 深度梯度大（边界处）→ 权重小
    # 深度梯度小（平坦区域）→ 权重大
    edge_weight = torch.exp(-lambda_depth * depth_grad)  # [H, W]
    
    # 6. 结合语义相似度和深度连续性
    consistency = semantic_sim * edge_weight  # [H, W]
    
    return consistency


def refine_pseudo_labels(
    projected_feat: torch.Tensor,      # [512, H, W]  detached, no grad
    current_mask: torch.Tensor,        # [H, W] int — current supervision mask
    anchors: torch.Tensor,             # [num_ids, 512]
    consistency_score: torch.Tensor,   # [H, W] in [0, 1]
    valid_ids: torch.Tensor | None = None,
    confidence_threshold: float = 0.5,
    accept_threshold: float = 0.6,
    min_low_conf_ratio: float = 0.01,
    margin_threshold: float = 0.05,
    disable_gate1: bool = False,
    disable_gate2: bool = False,
    disable_gate3: bool = False,
) -> torch.Tensor:
    """
    GSFL 伪标签精细化 (pseudo-label refinement)。

    三阈值门控设计（防止细粒度场景中锚点混淆导致的循环推理）：
    - 第一关：consistency < confidence_threshold → 该像素需要修正（低置信）
    - 第二关：新标签的余弦相似度 >= accept_threshold → 新标签绝对可信
    - 第三关：best_sim - second_best_sim >= margin_threshold → 新标签相对明显优于其他锚点

    第三关 (margin gate) 是对细粒度场景的关键保护：当多个锚点 CLIP 嵌入高度相似时
    （如 17 个玩具，平均相似度 0.66），即使最近邻也可能只是"最不差的错误"。
    只有在最优锚点与次优锚点之间存在明显间隔时，才认为新标签具有足够判别性。

    Returns:
        refined_mask [H, W] int (same dtype as current_mask)
    """
    H, W = current_mask.shape
    refined_mask = current_mask.clone()

    if disable_gate1:
        low_conf = torch.ones_like(current_mask, dtype=torch.bool)
    else:
        low_conf = consistency_score < confidence_threshold   # [H, W]
    low_conf_flat = low_conf.reshape(-1)                  # [H*W]

    # 低置信像素数量不足时跳过，避免早期训练引入噪声
    low_ratio = low_conf_flat.float().mean().item()
    if low_ratio < min_low_conf_ratio or not low_conf_flat.any():
        return refined_mask

    # 提取低置信像素的特征
    feat_flat = projected_feat.permute(1, 2, 0).reshape(-1, projected_feat.shape[0])  # [H*W, 512]
    low_feat = feat_flat[low_conf_flat]  # [N_low, 512]

    if valid_ids is None:
        valid_ids = torch.arange(1, anchors.shape[0], device=anchors.device, dtype=torch.long)
    else:
        valid_ids = valid_ids.to(device=anchors.device, dtype=torch.long)
        valid_ids = valid_ids[valid_ids > 0]
    if valid_ids.numel() == 0:
        return refined_mask

    # 余弦最近邻 → 候选新标签
    low_feat_norm = F.normalize(low_feat, dim=1)          # [N_low, 512]
    anchors_norm  = F.normalize(anchors[valid_ids], dim=1)   # [num_valid, 512]
    sims    = low_feat_norm @ anchors_norm.T                 # [N_low, num_valid]
    best_sim, new_idx = sims.max(dim=1)                      # [N_low], [N_low]
    new_ids = valid_ids[new_idx]

    # 第二关门控：新标签的最大相似度必须 >= accept_threshold
    # 不满足说明特征尚未收敛，保留原标签以避免循环推理
    if disable_gate2:
        accepted = torch.ones_like(best_sim, dtype=torch.bool)
    else:
        accepted = best_sim >= accept_threshold               # [N_low] bool

    # 第三关门控 (margin gate)：只有当最优锚点明显优于次优锚点时才接受
    # 防止细粒度场景（锚点间高相似度）中的随机错误重标注
    if (not disable_gate3) and sims.shape[1] > 1 and margin_threshold > 0.0:
        top2_sims, _ = sims.topk(2, dim=1)               # [N_low, 2]
        margin = top2_sims[:, 0] - top2_sims[:, 1]       # [N_low]
        accepted = accepted & (margin >= margin_threshold)

    # 写回精细化掩码（仅通过三重门控的像素）
    refined_flat = refined_mask.reshape(-1)
    low_conf_indices = low_conf_flat.nonzero(as_tuple=False).squeeze(1)  # [N_low]
    accepted_indices = low_conf_indices[accepted]                         # [N_accept]
    refined_flat[accepted_indices] = new_ids[accepted].to(refined_flat.dtype)

    return refined_flat.reshape(H, W)


def update_anchors_online(
    anchors: torch.Tensor,            # [num_ids, 512]  current anchors
    projected_feat: torch.Tensor,     # [512, H, W]  detached
    mask: torch.Tensor,               # [H, W] int
    consistency_score: torch.Tensor,  # [H, W]
    valid_ids: torch.Tensor | None = None,
    momentum: float = 0.99,
    confidence_threshold: float = 0.6,
    min_pixels: int = 10,
) -> torch.Tensor:
    """
    GSFL 锚点在线更新 (online anchor refinement)。

    使用指数移动平均 (EMA) 从高置信像素聚合特征，
    逐步将 semantic anchors 从 VLM/CLIP 描述对齐到 3D 高斯的真实特征分布。

    只有满足 consistency >= confidence_threshold 且像素数 >= min_pixels
    的对象 ID 才会触发更新，避免低质量样本污染锚点。

    Returns:
        updated anchors [num_ids, 512]
    """
    feat_flat = projected_feat.permute(1, 2, 0).reshape(-1, projected_feat.shape[0])  # [H*W, 512]
    mask_flat = mask.reshape(-1).long()           # [H*W]
    conf_flat = consistency_score.reshape(-1)     # [H*W]

    new_anchors = anchors.clone()

    if valid_ids is None:
        valid_ids = torch.arange(1, anchors.shape[0], device=anchors.device, dtype=torch.long)
    else:
        valid_ids = valid_ids.to(device=anchors.device, dtype=torch.long)
        valid_ids = valid_ids[valid_ids > 0]

    for obj_id_t in valid_ids:
        obj_id = int(obj_id_t.item())
        obj_high_conf = (mask_flat == obj_id) & (conf_flat >= confidence_threshold)
        if obj_high_conf.sum().item() < min_pixels:
            continue

        obj_feat      = feat_flat[obj_high_conf]                  # [N, 512]
        obj_feat_mean = F.normalize(obj_feat.mean(dim=0), dim=0)  # [512]

        # EMA：以 momentum 保留旧锚点，(1-momentum) 融入新观测
        new_anchors[obj_id] = momentum * anchors[obj_id] + (1.0 - momentum) * obj_feat_mean
        new_anchors[obj_id] = F.normalize(new_anchors[obj_id], dim=0)

    return new_anchors


def update_anchors_from_deva(
    anchors: torch.Tensor,          # [num_ids, 512]  current anchors
    projected_feat: torch.Tensor,   # [512, H, W]  detached
    deva_mask: torch.Tensor,        # [H, W] int  — external GT pseudo-labels (DEVA)
    valid_ids: torch.Tensor | None = None,
    momentum: float = 0.999,
    min_pixels: int = 10,
) -> torch.Tensor:
    """
    DEVA 引导的锚点安全更新（E11 引入）。

    与 update_anchors_online 的核心区别：
      - 不依赖模型自身预测（consistency_score），彻底打破循环推理
      - 直接使用外部 DEVA 掩码确定像素归属
      - momentum 默认 0.999（更保守），防止单帧扰动导致锚点漂移

    效果：锚点逐步对齐 3D 高斯真实特征分布，
    使伪标签精化（refine_pseudo_labels）的判断更准确。

    Returns:
        updated anchors [num_ids, 512]
    """
    import torch.nn.functional as F_local

    feat_flat = projected_feat.permute(1, 2, 0).reshape(-1, projected_feat.shape[0])  # [H*W, 512]
    deva_flat = deva_mask.reshape(-1).long()  # [H*W]

    new_anchors = anchors.clone()

    if valid_ids is None:
        valid_ids = torch.arange(1, anchors.shape[0], device=anchors.device, dtype=torch.long)
    else:
        valid_ids = valid_ids.to(device=anchors.device, dtype=torch.long)
        valid_ids = valid_ids[valid_ids > 0]

    for obj_id_t in valid_ids:
        obj_id = int(obj_id_t.item())
        obj_pix = (deva_flat == obj_id)
        if obj_pix.sum().item() < min_pixels:
            continue

        obj_feat      = feat_flat[obj_pix]                          # [N, 512]
        obj_feat_mean = F_local.normalize(obj_feat.mean(dim=0), dim=0)  # [512]

        new_anchors[obj_id] = momentum * anchors[obj_id] + (1.0 - momentum) * obj_feat_mean
        new_anchors[obj_id] = F_local.normalize(new_anchors[obj_id], dim=0)

    return new_anchors
