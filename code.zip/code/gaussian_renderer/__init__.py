#
# Copyright (C) 2023, Inria
# GRAPHDECO research group, https://team.inria.fr/graphdeco
# All rights reserved.
#
# This software is free for non-commercial, research and evaluation use 
# under the terms of the LICENSE.md file.
#
# For inquiries contact  george.drettakis@inria.fr
#

import torch
import math
import inspect
try:
    from diff_gauss import GaussianRasterizationSettings, GaussianRasterizer
except ImportError:
    from diff_gaussian_rasterization import GaussianRasterizationSettings, GaussianRasterizer
from scene.gaussian_model import GaussianModel
from utils.sh_utils import eval_sh
import torch.nn.functional as F

def render(viewpoint_camera, pc : GaussianModel, pipe, bg_color : torch.Tensor, scaling_modifier = 1.0, separate_sh = False, override_color = None, use_trained_exp=False):
    """
    Render the scene. 
    
    Background tensor (bg_color) must be on GPU!
    
    Returns:
        out (dict): Contains keys:
            - "render": Rendered RGB image [3, H, W]
            - "viewspace_points": Screen-space points with gradients
            - "visibility_filter": Visible points mask
            - "radii": Gaussian radii on screen
            - "depth": Rendered depth map [1, H, W]
            - "semantic": Rendered semantic features [d, H, W] (NEW for SAD-GS)
    """
 
    # Create zero tensor. We will use it to make pytorch return gradients of the 2D (screen-space) means
    screenspace_points = torch.zeros_like(pc.get_xyz, dtype=pc.get_xyz.dtype, requires_grad=True, device="cuda") + 0
    try:
        screenspace_points.retain_grad()
    except:
        pass

    # Set up rasterization configuration
    tanfovx = math.tan(viewpoint_camera.FoVx * 0.5)
    tanfovy = math.tan(viewpoint_camera.FoVy * 0.5)

    raster_settings_kwargs = {
        "image_height": int(viewpoint_camera.image_height),
        "image_width": int(viewpoint_camera.image_width),
        "tanfovx": tanfovx,
        "tanfovy": tanfovy,
        "bg": bg_color,
        "scale_modifier": scaling_modifier,
        "viewmatrix": viewpoint_camera.world_view_transform,
        "projmatrix": viewpoint_camera.full_proj_transform,
        "sh_degree": pc.active_sh_degree,
        "campos": viewpoint_camera.camera_center,
        "prefiltered": False,
        "debug": pipe.debug,
    }
    settings_sig = inspect.signature(GaussianRasterizationSettings)
    if "antialiasing" in settings_sig.parameters:
        raster_settings_kwargs["antialiasing"] = getattr(pipe, "antialiasing", False)
    raster_settings = GaussianRasterizationSettings(**raster_settings_kwargs)

    rasterizer = GaussianRasterizer(raster_settings=raster_settings)

    means3D = pc.get_xyz
    means2D = screenspace_points
    opacity = pc.get_opacity

    # If precomputed 3d covariance is provided, use it. If not, then it will be computed from
    # scaling / rotation by the rasterizer.
    scales = None
    rotations = None
    cov3D_precomp = None

    if pipe.compute_cov3D_python:
        cov3D_precomp = pc.get_covariance(scaling_modifier)
    else:
        scales = pc.get_scaling
        rotations = pc.get_rotation

    # If precomputed colors are provided, use them. Otherwise, if it is desired to precompute colors
    # from SHs in Python, do it. If not, then SH -> RGB conversion will be done by rasterizer.
    shs = None
    colors_precomp = None
    if override_color is None:
        if pipe.convert_SHs_python:
            shs_view = pc.get_features.transpose(1, 2).view(-1, 3, (pc.max_sh_degree+1)**2)
            dir_pp = (pc.get_xyz - viewpoint_camera.camera_center.repeat(pc.get_features.shape[0], 1))
            dir_pp_normalized = dir_pp/dir_pp.norm(dim=1, keepdim=True)
            sh2rgb = eval_sh(pc.active_sh_degree, shs_view, dir_pp_normalized)
            colors_precomp = torch.clamp_min(sh2rgb + 0.5, 0.0)
        else:
            if separate_sh:
                dc, shs = pc.get_features_dc, pc.get_features_rest
            else:
                shs = pc.get_features
    else:
        colors_precomp = override_color

    # --- SAD-GS: Prepare semantic features ---
    semantic_features = None
    try:
        if pc._language_feature is not None:
            semantic_features = pc.get_language_feature  # [N, 16]
    except:
        pass

    # Rasterize visible Gaussians to image, obtain their radii (on screen).
    # Support both APIs:
    # - diff_gaussian_rasterization: semantics=..., returns (color, semant, radii, depth, alpha)
    # - diff_gauss: extra_attrs=..., returns (color, depth, norm, alpha, radii, extra)
    kwargs = {
        "means3D": means3D,
        "means2D": means2D,
        "shs": shs,
        "colors_precomp": colors_precomp,
        "opacities": opacity,
        "scales": scales,
        "rotations": rotations,
    }

    sig = inspect.signature(rasterizer.forward)
    if "cov3D_precomp" in sig.parameters:
        kwargs["cov3D_precomp"] = cov3D_precomp
    elif "cov3Ds_precomp" in sig.parameters:
        kwargs["cov3Ds_precomp"] = cov3D_precomp

    if "semantics" in sig.parameters:
        kwargs["semantics"] = semantic_features
    elif "extra_attrs" in sig.parameters:
        kwargs["extra_attrs"] = semantic_features

    outputs = rasterizer(**kwargs)
    if len(outputs) == 5:
        rendered_image, rendered_semantic, radii, depth_image, alpha = outputs
    elif len(outputs) == 6:
        rendered_image, depth_image, _rendered_norm, alpha, radii, rendered_semantic = outputs
    else:
        raise RuntimeError(f"Unexpected rasterizer outputs: {len(outputs)}")
        
    # Apply exposure to rendered image (training only)
    if use_trained_exp:
        exposure = pc.get_exposure_from_name(viewpoint_camera.image_name)
        rendered_image = torch.matmul(rendered_image.permute(1, 2, 0), exposure[:3, :3]).permute(2, 0, 1) + exposure[:3, 3,   None, None]

    # Those Gaussians that were frustum culled or had a radius of 0 were not visible.
    # They will be excluded from value updates used in the splitting criteria.
    rendered_image = rendered_image.clamp(0, 1)
    
    # SAD-GS: Add semantic features to output
    out = {
        "render": rendered_image,
        "viewspace_points": screenspace_points,
        "visibility_filter" : (radii > 0).nonzero(),
        "radii": radii,
        "depth" : depth_image,
        "semantic": rendered_semantic if rendered_semantic is not None else torch.zeros(
            0 if semantic_features is None else semantic_features.shape[1],
            int(viewpoint_camera.image_height),
            int(viewpoint_camera.image_width),
            device="cuda",
        )
        }
    
    return out
