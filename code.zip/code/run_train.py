"""
SAD-GS training launcher.
Usage:
    python run_train.py --source_path <scene> --model_path <out> [options]

Extra args not in OptimizationParams:
    --geometry_iters   int   iterations for Stage 1 (default: 30000)
    --semantic_feature_dim int semantic feature dimension for Gaussian attributes (default: 16)
    --lambda_sad       float SAD loss weight      (default: 0.1)
    --lambda_id_ce     float ID CE loss weight    (default: 0.0)
    --id_ce_temperature float CE logits temperature (default: 0.07)
    --deva_mask_dir    str   path to DEVA masks   (default: None)
"""
import sys
import os
import torch
from argparse import ArgumentParser
from arguments import ModelParams, OptimizationParams, PipelineParams
from train import training
from utils.general_utils import safe_state

if __name__ == "__main__":
    parser = ArgumentParser(description="SAD-GS Training")
    lp = ModelParams(parser)
    op = OptimizationParams(parser)
    pp = PipelineParams(parser)

    parser.add_argument('--ip', type=str, default="127.0.0.1")
    parser.add_argument('--port', type=int, default=12652)
    parser.add_argument('--debug_from', type=int, default=-1)
    parser.add_argument('--detect_anomaly', action='store_true', default=False)
    parser.add_argument("--test_iterations", nargs="+", type=int, default=[])
    parser.add_argument("--saving_iterations", nargs="+", type=int, default=[])
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--checkpoint_iterations", nargs="+", type=int, default=[])
    parser.add_argument("--start_checkpoint", type=str, default=None)

    # SAD-GS extra params
    parser.add_argument("--geometry_iters", type=int, default=30000)
    parser.add_argument("--lambda_sad", type=float, default=0.1)
    parser.add_argument("--lambda_id_ce", type=float, default=0.0)
    parser.add_argument("--id_ce_temperature", type=float, default=0.07)
    parser.add_argument("--deva_mask_dir", type=str, default=None)
    parser.add_argument("--ablation_mode", type=str, default="full", choices=["full", "sad_only", "gsfl_only"],
                        help="Ablation mode: 'full' (SAD+GSFL), 'sad_only' (disable GSFL weighting), 'gsfl_only' (only GSFL consistency)")

    # GSFL 反馈循环参数
    parser.add_argument("--gsfl_warmup_iters", type=int, default=5000,
                        help="Stage-2 内预热步数，之后才激活 GSFL 伪标签更新（默认 5000）")
    parser.add_argument("--gsfl_conf_threshold", type=float, default=0.5,
                        help="自适应置信阈值起点（宽松），随训练线性增至 gsfl_conf_end（默认 0.5）")
    parser.add_argument("--gsfl_conf_end", type=float, default=0.65,
                        help="自适应置信阈值终点（严格），GSFL 激活后 gsfl_conf_ramp_iters 步达到（默认 0.65）")
    parser.add_argument("--gsfl_conf_ramp_iters", type=int, default=10000,
                        help="置信阈值从 start 线性增至 end 所需步数（默认 10000）")
    parser.add_argument("--gsfl_accept_threshold", type=float, default=0.6,
                        help="新标签的余弦相似度接受阈值，低于此值不修改标签（默认 0.6，防循环推理）")
    parser.add_argument("--gsfl_margin_threshold", type=float, default=0.05,
                        help="Gate 3 margin threshold: best anchor similarity must exceed runner-up by this value")
    parser.add_argument("--gsfl_disable_gate1", action="store_true", default=False,
                        help="消融：关闭 Gate 1（不再用 low-consistency 过滤进入 PLR 的像素）")
    parser.add_argument("--gsfl_disable_gate2", action="store_true", default=False,
                        help="消融：关闭 Gate 2（不再要求候选标签满足绝对相似度阈值）")
    parser.add_argument("--gsfl_disable_gate3", action="store_true", default=False,
                        help="消融：关闭 Gate 3（不再要求最优锚点与次优锚点存在 margin）")
    parser.add_argument("--gsfl_lambda_depth", type=float, default=0.1,
                        help="深度梯度权重系数（默认 0.1）")
    parser.add_argument("--pseudo_label_update_interval", type=int, default=500,
                        help="伪标签精细化更新周期（每 N 步执行一次 Stage-2 内，默认 500）")
    parser.add_argument("--gsfl_enable_pseudo_refine", action="store_true", default=True,
                        help="是否启用 GSFL 伪标签精细化（消融开关，默认开启）")
    parser.add_argument("--no_gsfl_pseudo_refine", dest="gsfl_enable_pseudo_refine",
                        action="store_false",
                        help="关闭 GSFL 伪标签精细化（用于消融：full 模式仅保留 anchor EMA 更新）")
    parser.add_argument("--anchor_ema_momentum", type=float, default=0.99,
                        help="锚点 EMA 更新动量，越大越保守（默认 0.99）")
    parser.add_argument("--anchor_update_interval", type=int, default=100,
                        help="锚点更新间隔步数（默认每 100 步更新一次）")
    parser.add_argument("--gsfl_enable_anchor_update", action="store_true", default=False,
                        help="是否启用 GSFL 锚点在线 EMA 更新（默认关闭，避免锚点污染）")
    parser.add_argument("--no_gsfl_anchor_update", dest="gsfl_enable_anchor_update",
                        action="store_false",
                        help="关闭 GSFL 锚点在线更新（默认行为，用于消融对照）")
    # E11: DEVA-guided safe anchor update
    parser.add_argument("--gsfl_enable_deva_anchor_update", action="store_true", default=False,
                        help="E11: 启用 DEVA 引导锚点安全更新（用外部 DEVA 掩码更新锚点，无循环推理）")
    parser.add_argument("--no_gsfl_deva_anchor_update", dest="gsfl_enable_deva_anchor_update",
                        action="store_false",
                        help="关闭 DEVA 引导锚点更新（默认行为）")
    parser.add_argument("--deva_anchor_update_interval", type=int, default=500,
                        help="DEVA 引导锚点更新间隔步数（默认 500，E11）")
    parser.add_argument("--deva_anchor_ema_momentum", type=float, default=0.999,
                        help="DEVA 引导锚点 EMA 动量（默认 0.999，保守更新）")
    parser.add_argument("--pseudo_label_batch_interval", type=int, default=2000,
                        help="全量批次伪标签更新周期（每 N 个 Stage-2 步遍历所有相机，0 禁用，默认 2000）")

    args = parser.parse_args(sys.argv[1:])
    args.saving_iterations.append(args.iterations)

    # Extract param groups
    lp_extracted = lp.extract(args)
    op_extracted = op.extract(args)

    # Attach extra SAD-GS params to op so train.py can read via getattr
    op_extracted.geometry_iters = args.geometry_iters
    op_extracted.semantic_feature_dim = args.semantic_feature_dim
    op_extracted.lambda_sad = args.lambda_sad
    op_extracted.lambda_id_ce = args.lambda_id_ce
    op_extracted.id_ce_temperature = args.id_ce_temperature
    op_extracted.ablation_mode = args.ablation_mode
    op_extracted.gsfl_warmup_iters      = args.gsfl_warmup_iters
    op_extracted.gsfl_conf_threshold    = args.gsfl_conf_threshold
    op_extracted.gsfl_conf_end          = args.gsfl_conf_end
    op_extracted.gsfl_conf_ramp_iters   = args.gsfl_conf_ramp_iters
    op_extracted.gsfl_accept_threshold  = args.gsfl_accept_threshold
    op_extracted.gsfl_margin_threshold  = args.gsfl_margin_threshold
    op_extracted.gsfl_disable_gate1     = args.gsfl_disable_gate1
    op_extracted.gsfl_disable_gate2     = args.gsfl_disable_gate2
    op_extracted.gsfl_disable_gate3     = args.gsfl_disable_gate3
    op_extracted.gsfl_lambda_depth      = args.gsfl_lambda_depth
    op_extracted.pseudo_label_update_interval = args.pseudo_label_update_interval
    op_extracted.gsfl_enable_pseudo_refine    = args.gsfl_enable_pseudo_refine
    op_extracted.anchor_ema_momentum    = args.anchor_ema_momentum
    op_extracted.anchor_update_interval = args.anchor_update_interval
    op_extracted.gsfl_enable_anchor_update = args.gsfl_enable_anchor_update
    op_extracted.gsfl_enable_deva_anchor_update = args.gsfl_enable_deva_anchor_update
    op_extracted.deva_anchor_update_interval = args.deva_anchor_update_interval
    op_extracted.deva_anchor_ema_momentum = args.deva_anchor_ema_momentum
    op_extracted.pseudo_label_batch_interval = args.pseudo_label_batch_interval

    # Attach deva_mask_dir to dataset params (camera_utils reads from args/dataset)
    lp_extracted.deva_mask_dir = args.deva_mask_dir

    print("Optimizing " + lp_extracted.model_path)

    safe_state(args.quiet)
    torch.autograd.set_detect_anomaly(args.detect_anomaly)

    training(
        lp_extracted, op_extracted, pp.extract(args),
        args.test_iterations,
        args.saving_iterations,
        args.checkpoint_iterations,
        args.start_checkpoint,
        args.debug_from,
    )
    print("Training done.")
