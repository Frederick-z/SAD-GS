import torch
import os
import sys
import random
import json
import time
from random import randint
from tqdm import tqdm
from gaussian_renderer import render
from scene import Scene
from scene.gaussian_model import GaussianModel
from utils.loss_utils import l1_loss, ssim
from utils.semantic_utils import (
    SemanticDistiller, compute_gsfl_consistency,
    refine_pseudo_labels, update_anchors_online, update_anchors_from_deva,
)
import torch.nn.functional as F

def training(dataset, opt, pipe, testing_iterations, saving_iterations, checkpoint_iterations, checkpoint, debug_from):
    """
    SAD-GS 两阶段训练：
    - Stage 1 (iter 0-geometry_iters):   纯几何优化，learning geometry
    - Stage 2 (iter geometry_iters+1):   语义蒸馏，freezing geometry
    """
    first_iter = 0
    train_start_time = time.perf_counter()
    stage = "geometric"  # 初始阶段
    semantic_distiller_checkpoint = None  # Stage 2 checkpoint
    
    gaussians = GaussianModel(dataset.sh_degree)
    scene = Scene(dataset, gaussians)
    
    # 根据阶段选择是否包含语义特征
    opt.include_feature = False  # Stage 1: 关闭语义特征
    gaussians.training_setup(opt)
    
    if checkpoint:
        (model_params, first_iter) = torch.load(checkpoint, weights_only=False)
        gaussians.restore(model_params, opt)

    bg_color = [1, 1, 1] if dataset.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")

    # --- Stage 2 初始化（延迟初始化）---
    distiller = None
    stage_2_start_iter = getattr(opt, 'geometry_iters', 30000)
    semantic_feature_dim = int(getattr(opt, "semantic_feature_dim", 16))
    if semantic_feature_dim > 34:
        raise ValueError(
            f"semantic_feature_dim={semantic_feature_dim} exceeds the current rasterizer limit (34)."
        )
    lambda_id_ce = getattr(opt, 'lambda_id_ce', 0.0)
    id_ce_temperature = max(getattr(opt, 'id_ce_temperature', 0.07), 1e-6)
    masked_train_cameras = [cam for cam in scene.getTrainCameras() if cam.deva_mask is not None]
    print(f"Masked train cameras: {len(masked_train_cameras)} / {len(scene.getTrainCameras())}")
    
    # 消融模式配置
    ablation_mode = getattr(opt, 'ablation_mode', 'full')
    print(f"Ablation mode: {ablation_mode}")
    assert ablation_mode in ['full', 'sad_only', 'gsfl_only'], f"Invalid ablation_mode: {ablation_mode}"

    # GSFL 反馈循环状态（仅 full 模式使用）
    # refined_masks: cam.image_name → 精细化后的掩码 Tensor [H, W]（存 CPU）
    refined_masks: dict = {}
    gsfl_warmup_iters    = getattr(opt, 'gsfl_warmup_iters', 5000)
    gsfl_conf_start      = getattr(opt, 'gsfl_conf_threshold', 0.5)
    gsfl_conf_end        = getattr(opt, 'gsfl_conf_end', 0.65)
    gsfl_conf_ramp_iters = getattr(opt, 'gsfl_conf_ramp_iters', 10000)
    gsfl_accept_threshold        = getattr(opt, 'gsfl_accept_threshold', 0.6)
    gsfl_margin_threshold        = getattr(opt, 'gsfl_margin_threshold', 0.05)
    gsfl_disable_gate1           = getattr(opt, 'gsfl_disable_gate1', False)
    gsfl_disable_gate2           = getattr(opt, 'gsfl_disable_gate2', False)
    gsfl_disable_gate3           = getattr(opt, 'gsfl_disable_gate3', False)
    anchor_ema_momentum          = getattr(opt, 'anchor_ema_momentum', 0.99)
    anchor_update_interval       = getattr(opt, 'anchor_update_interval', 100)
    # 锚点在线 EMA 更新独立开关（默认 False，避免锚点污染导致负迁移）
    gsfl_enable_anchor_update    = getattr(opt, 'gsfl_enable_anchor_update', False)
    # DEVA 引导锚点更新（E11 新增）：用外部 DEVA 掩码更新锚点，默认 OFF（需显式开启）
    gsfl_enable_deva_anchor_update  = getattr(opt, 'gsfl_enable_deva_anchor_update', False)
    deva_anchor_update_interval     = getattr(opt, 'deva_anchor_update_interval', 500)
    deva_anchor_ema_momentum        = getattr(opt, 'deva_anchor_ema_momentum', 0.999)
    # 伪标签更新周期（对应 ROADMAP: 每500迭代更新一次）
    pseudo_label_update_interval = getattr(opt, 'pseudo_label_update_interval', 500)
    # 伪标签精细化独立开关（消融：full 模式可单独关闭此项）
    gsfl_enable_pseudo_refine    = getattr(opt, 'gsfl_enable_pseudo_refine', True)
    # 全量批次伪标签更新周期：每 N 步遍历所有带掩码相机，解决 25/124 瓶颈
    # 设为 0 或负数则禁用批量更新（默认 2000，Stage-2 约每 2000 步全量刷新一次）
    pseudo_label_batch_interval  = getattr(opt, 'pseudo_label_batch_interval', 2000)


    progress_bar = tqdm(range(first_iter, opt.iterations), desc="Training progress")
    first_iter += 1
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()

    for iteration in range(first_iter, opt.iterations + 1):
        # --- 阶段切换逻辑 ---
        if iteration == stage_2_start_iter + 1 and stage == "geometric":
            stage = "semantic"
            print(f"\n[Epoch {iteration}] Switching to Stage 2: Semantic Distillation")
            
            # 冻结几何参数
            opt.include_feature = True
            gaussians.training_setup(opt)
            
            # 初始化语义蒸馏器
            distiller = SemanticDistiller(feature_dim=semantic_feature_dim, clip_dim=512).cuda()
            anchor_path = os.path.join(dataset.source_path, "semantic_anchors.pt")
            if os.path.exists(anchor_path):
                distiller.load_anchors(anchor_path)
                print(f"Loaded semantic anchors from {anchor_path}")
            else:
                print(f"[Warning] No semantic anchors found at {anchor_path}")
        
        # --- Stage 1: 几何优化 ---
        if stage == "geometric":
            gaussians.update_learning_rate(iteration)
            
            if iteration % 1000 == 0:
                gaussians.oneupSHdegree()

            # 随机选取相机
            viewpoint_cam = random.choice(scene.getTrainCameras())

            # 渲染
            render_pkg = render(viewpoint_cam, gaussians, pipe, background)
            image = render_pkg["render"]

            # RGB Loss （标准3DGS）
            gt_image = viewpoint_cam.original_image.cuda()
            Ll1 = l1_loss(image, gt_image)
            loss = (1.0 - opt.lambda_dssim) * Ll1 + opt.lambda_dssim * (1.0 - ssim(image, gt_image))

            # 反向传播
            loss.backward()
            
            with torch.no_grad():
                if iteration % 10 == 0:
                    progress_bar.set_postfix({"Loss": f"{loss.item():.4f}", "Stage": "Geometric"})
                    progress_bar.update(10)

                gaussians.optimizer.step()
                gaussians.optimizer.zero_grad(set_to_none=True)

                # 稠密化与修剪
                if iteration < opt.densify_until_iter:
                    gaussians.add_densification_stats(render_pkg["viewspace_points"], render_pkg["visibility_filter"])
                    if iteration > opt.densify_from_iter and iteration % opt.densification_interval == 0:
                        gaussians.densify_and_prune(opt.densify_grad_threshold, 0.005, scene.cameras_extent, None)

                # 定期保存（Stage 1）
                if iteration in saving_iterations:
                    print(f"[Stage 1] Saving checkpoint at iteration {iteration}")
                    scene.save(iteration)

        # --- Stage 2: 语义蒸馏 ---
        else:
            assert distiller is not None, "Distiller not initialized for Stage 2"
            
            gaussians.update_learning_rate(iteration)
            distiller.update_learning_rate(iteration, warmup_iters=stage_2_start_iter)

            # 优先从有 DEVA 掩码的相机中采样，避免语义损失长期为 N/A
            if masked_train_cameras:
                viewpoint_cam = random.choice(masked_train_cameras)
            else:
                viewpoint_cam = random.choice(scene.getTrainCameras())

            # 渲染
            render_pkg = render(viewpoint_cam, gaussians, pipe, background)
            image = render_pkg["render"]
            depth = render_pkg["depth"]
            semantic_feat_16d = render_pkg["semantic"]  # [d, H, W]

            # --- RGB Loss（维持渲染质量）---
            gt_image = viewpoint_cam.original_image.cuda()
            Ll1 = l1_loss(image, gt_image)
            loss_rgb = (1.0 - opt.lambda_dssim) * Ll1 + opt.lambda_dssim * (1.0 - ssim(image, gt_image))
            loss = loss_rgb

            # --- SAD 语义蒸馏 Loss ---
            loss_sad = None
            loss_gsfl = None
            loss_id_ce = None
            consistency_mean_val  = 0.0   # 日志预初始化，full 模式会覆盖
            label_change_rate_val = 0.0
            anchor_delta_val = 0.0
            deva_anchor_delta_val = 0.0
            anchor_update_applied = 0
            deva_anchor_update_applied = 0
            if distiller.has_anchors and viewpoint_cam.deva_mask is not None:
                deva_mask = viewpoint_cam.deva_mask.cuda()  # [H, W]  原始 DEVA 伪标签
                cam_key   = viewpoint_cam.image_name

                # ── 监督掩码选择 ──────────────────────────────────────────────────
                # ⚠️  消融隔离规则：
                #   - sad_only / gsfl_only：永远使用原始 DEVA 掩码，不受 GSFL 影响
                #   - full：若 GSFL 已为该相机生成精细化掩码，才替换；否则同 sad_only
                # refined_masks 只由 full 模式写入，其他模式永远读不到，隔离天然成立。
                if ablation_mode == "full" and cam_key in refined_masks:
                    supervision_mask = refined_masks[cam_key].cuda()
                else:
                    supervision_mask = deva_mask   # sad_only / gsfl_only 恒走此分支
                
                # 维度投影: 16d -> 512d
                projected_feat_512d = distiller.project(semantic_feat_16d)  # [512, H, W]
                
                # 获取目标锚点（使用监督掩码，非一定是原始 deva_mask）
                target_anchors = distiller.get_target_anchors(supervision_mask)  # [512, H, W]
                valid_anchor_ids_t = distiller.get_valid_anchor_ids_tensor()
                
                # ── 消融分支（三路互斥，逻辑严格隔离）────────────────────────────
                # ablation_mode = "sad_only"  → 原始 SAD，无任何 GSFL 干预（历史基线）
                # ablation_mode = "gsfl_only" → 纯一致性损失，无 SAD（GSFL 单独贡献对照）
                # ablation_mode = "full"      → SAD + GSFL 反馈闭环（完整方法）
                # 日志变量预初始化（仅 full 模式会真正写入）
                consistency_mean_val  = 0.0
                label_change_rate_val = 0.0
                if ablation_mode == "full":
                    # 完整 GSFL 模式：
                    #   1. SAD 使用均匀权重（与 sad_only 相同的梯度强度）
                    #   2. GSFL 反馈循环在 no_grad 区内异步更新伪标签和锚点
                    loss_sad = distiller.compute_distillation_loss(projected_feat_512d, target_anchors)
                    loss += getattr(opt, 'lambda_sad', 0.1) * loss_sad

                    # GSFL 反馈循环（预热结束后激活，no_grad 以避免二阶导数）
                    gsfl_active_iter = stage_2_start_iter + gsfl_warmup_iters
                    if iteration > gsfl_active_iter:
                        with torch.no_grad():
                            stage2_elapsed = iteration - stage_2_start_iter

                            # Step A: 计算几何-语义一致性分数（每步都算，用于监控）
                            consistency_score = compute_gsfl_consistency(
                                projected_feat_512d.detach(), target_anchors.detach(), depth,
                                lambda_depth=getattr(opt, 'gsfl_lambda_depth', 0.1),
                            )
                            consistency_mean_val = consistency_score.mean().item()

                            # 自适应置信阈值：GSFL 激活后从 start 线性增至 end
                            ramp_progress = min(
                                1.0,
                                (iteration - gsfl_active_iter) / max(gsfl_conf_ramp_iters, 1)
                            )
                            current_conf_threshold = (
                                gsfl_conf_start + (gsfl_conf_end - gsfl_conf_start) * ramp_progress
                            )

                            # Step B: 伪标签周期精细化（受 pseudo_label_update_interval 调度）
                            # 独立开关 gsfl_enable_pseudo_refine 可单独关闭用于消融
                            if (gsfl_enable_pseudo_refine
                                    and stage2_elapsed % pseudo_label_update_interval == 0):
                                old_mask = supervision_mask
                                refined = refine_pseudo_labels(
                                    projected_feat_512d.detach(),
                                    supervision_mask,
                                    distiller.anchors,
                                    consistency_score,
                                    valid_ids=valid_anchor_ids_t,
                                    confidence_threshold=current_conf_threshold,
                                    accept_threshold=gsfl_accept_threshold,
                                    margin_threshold=gsfl_margin_threshold,
                                    disable_gate1=gsfl_disable_gate1,
                                    disable_gate2=gsfl_disable_gate2,
                                    disable_gate3=gsfl_disable_gate3,
                                )
                                refined_masks[cam_key] = refined.cpu()
                                label_change_rate_val = (refined.cpu() != old_mask.cpu()).float().mean().item()

                            # Step C: 锚点在线 EMA 更新（受 gsfl_enable_anchor_update 开关控制，默认 OFF）
                            if gsfl_enable_anchor_update and stage2_elapsed % anchor_update_interval == 0:
                                prev_anchors = distiller.anchors.clone()
                                distiller.anchors = update_anchors_online(
                                    distiller.anchors,
                                    projected_feat_512d.detach(),
                                    supervision_mask,
                                    consistency_score,
                                    valid_ids=valid_anchor_ids_t,
                                    momentum=anchor_ema_momentum,
                                    confidence_threshold=min(current_conf_threshold + 0.1, 0.9),
                                )
                                anchor_delta_val = (distiller.anchors - prev_anchors).norm(dim=1).mean().item()
                                anchor_update_applied = 1

                            # Step D: DEVA 引导锚点安全更新（E11 新增，--gsfl_enable_deva_anchor_update）
                            # 用外部 DEVA 标签选像素，彻底避免模型自循环导致锚点污染
                            if gsfl_enable_deva_anchor_update and stage2_elapsed % deva_anchor_update_interval == 0:
                                deva_mask_for_anchor = viewpoint_cam.deva_mask
                                if deva_mask_for_anchor is not None:
                                    prev_anchors = distiller.anchors.clone()
                                    distiller.anchors = update_anchors_from_deva(
                                        distiller.anchors,
                                        projected_feat_512d.detach(),
                                        deva_mask_for_anchor,
                                        valid_ids=valid_anchor_ids_t,
                                        momentum=deva_anchor_ema_momentum,
                                    )
                                    deva_anchor_delta_val = (distiller.anchors - prev_anchors).norm(dim=1).mean().item()
                                    deva_anchor_update_applied = 1

                elif ablation_mode == "sad_only":
                    # ── SAD-only（历史基线，代码严格保留原始形态）──────────────────
                    # supervision_mask = deva_mask（由上方公共赋值保证）
                    # 不计算 consistency_score，不写 refined_masks，不更新 anchors
                    # 与 2026-04-11 E4 消融实验的 sad_only 分支完全等价
                    loss_sad = distiller.compute_distillation_loss(projected_feat_512d, target_anchors)
                    loss += getattr(opt, 'lambda_sad', 0.1) * loss_sad

                elif ablation_mode == "gsfl_only":
                    # ── GSFL-only（无 SAD，仅一致性损失）────────────────────────────
                    # supervision_mask = deva_mask（由上方公共赋值保证）
                    # 最大化 3D 几何-语义一致性，作为 GSFL 单独贡献的对照组
                    consistency_score = compute_gsfl_consistency(
                        projected_feat_512d, target_anchors, depth
                    )
                    lambda_gsfl = getattr(opt, 'lambda_sad', 0.1)
                    loss_gsfl = (1.0 - consistency_score).mean()
                    loss += lambda_gsfl * loss_gsfl

                # ID 对齐损失：用锚点相似度做像素级分类，直接约束 track_id 对应关系。
                if lambda_id_ce > 0.0:
                    feat = projected_feat_512d.permute(1, 2, 0).reshape(-1, projected_feat_512d.shape[0])
                    feat = feat / feat.norm(dim=1, keepdim=True).clamp(min=1e-8)

                    anchors = distiller.anchors
                    anchors = anchors / anchors.norm(dim=1, keepdim=True).clamp(min=1e-8)
                    if distiller.use_sparse_anchor_ids:
                        valid_anchor_ids_t = distiller.get_valid_anchor_ids_tensor()
                        anchors_valid = anchors[valid_anchor_ids_t]
                        logits = (feat @ anchors_valid.T) / id_ce_temperature
                    else:
                        logits = (feat @ anchors.T) / id_ce_temperature

                    # ID-CE 同样使用 supervision_mask（可能为精细化掩码）
                    target_ids = supervision_mask.reshape(-1).long()
                    if distiller.use_sparse_anchor_ids:
                        compact_ids = distiller.anchor_dense_to_compact[target_ids.clamp(0, anchors.shape[0] - 1)]
                        valid = compact_ids >= 0
                    else:
                        compact_ids = target_ids
                        valid = (target_ids > 0) & (target_ids < anchors.shape[0])
                    if torch.any(valid):
                        loss_id_ce = F.cross_entropy(logits[valid], compact_ids[valid])
                        loss += lambda_id_ce * loss_id_ce

                if iteration % 100 == 0:
                    with torch.no_grad():
                        id_ce_str   = f", id_ce={loss_id_ce.item():.4f}" if loss_id_ce is not None else ""
                        sad_str     = f"sad={loss_sad.item():.4f}" if loss_sad is not None else ""
                        gsfl_str    = f"gsfl={loss_gsfl.item():.4f}" if loss_gsfl is not None else ""
                        if ablation_mode == "full":
                            gsfl_active_iter = stage_2_start_iter + gsfl_warmup_iters
                            gsfl_status = "active" if iteration > gsfl_active_iter else f"warmup({gsfl_active_iter - iteration})"
                            # 计算当前自适应阈值（仅用于显示）
                            ramp_p = min(1.0, max(0.0, (iteration - gsfl_active_iter) / max(gsfl_conf_ramp_iters, 1)))
                            cur_thr = gsfl_conf_start + (gsfl_conf_end - gsfl_conf_start) * ramp_p
                            extra = (
                                f", gsfl={gsfl_status}"
                                f", thr={cur_thr:.3f}"
                                f", consistency={consistency_mean_val:.4f}"
                                f", label_chg={label_change_rate_val:.3f}"
                                f", refined_cams={len(refined_masks)}/{len(masked_train_cameras)}"
                                f", anchor_delta={anchor_delta_val:.6f}"
                                f", deva_anchor_delta={deva_anchor_delta_val:.6f}"
                                f", anchor_upd={anchor_update_applied}"
                                f", deva_anchor_upd={deva_anchor_update_applied}"
                            )
                        else:
                            extra = f", mode={ablation_mode}"
                        print(
                            f"[GSFL Debug][iter {iteration}] "
                            f"{sad_str} {gsfl_str}{id_ce_str}{extra}"
                        )

            # 反向传播
            loss.backward()
            
            with torch.no_grad():
                if iteration % 10 == 0:
                    sad_str  = f"{loss_sad.item():.4f}"  if loss_sad  is not None else "N/A"
                    gsfl_str = f"{loss_gsfl.item():.4f}" if loss_gsfl is not None else "N/A"
                    id_ce_str = f"{loss_id_ce.item():.4f}" if loss_id_ce is not None else "N/A"
                    postfix = {
                        "RGB": f"{loss_rgb.item():.4f}",
                        "SAD": sad_str,
                        "IDCE": id_ce_str,
                        "Stage": "Semantic",
                    }
                    if ablation_mode == "full":
                        postfix["C̄"] = f"{consistency_mean_val:.3f}"   # 一致性均值
                        postfix["ΔL"] = f"{label_change_rate_val:.3f}"  # 标签变化率
                    else:
                        postfix["GSFL"] = gsfl_str
                    progress_bar.set_postfix(postfix)
                    progress_bar.update(10)

                # 优化器步进
                gaussians.optimizer.step()
                gaussians.optimizer.zero_grad(set_to_none=True)
                distiller.optimizer.step()
                distiller.optimizer.zero_grad(set_to_none=True)

                # 定期保存（Stage 2）
                if iteration in saving_iterations:
                    print(f"[Stage 2] Saving checkpoint at iteration {iteration}")
                    scene.save(iteration)
                    checkpoint_dir = os.path.join(dataset.model_path, "semantic_checkpoints")
                    distiller.save_projection_layer(checkpoint_dir, iteration)

                # ── 全量批次伪标签更新（解决 25/124 瓶颈）────────────────────────
                # 仅在 full 模式 + gsfl_enable_pseudo_refine + GSFL 激活后执行
                # 每 pseudo_label_batch_interval 步遍历所有带掩码相机，批量刷新 refined_masks
                _gsfl_active = stage_2_start_iter + gsfl_warmup_iters
                _stage2_elapsed_now = iteration - stage_2_start_iter
                if (ablation_mode == "full"
                        and gsfl_enable_pseudo_refine
                        and pseudo_label_batch_interval > 0
                        and iteration > _gsfl_active
                        and _stage2_elapsed_now > 0
                        and _stage2_elapsed_now % pseudo_label_batch_interval == 0):
                    # 计算当前自适应阈值（与 per-step 逻辑一致）
                    _ramp = min(1.0, (iteration - _gsfl_active) / max(gsfl_conf_ramp_iters, 1))
                    _cur_thr = gsfl_conf_start + (gsfl_conf_end - gsfl_conf_start) * _ramp
                    _n_updated = 0
                    for _cam in masked_train_cameras:
                        if _cam.deva_mask is None:
                            continue
                        _deva = _cam.deva_mask.cuda()
                        _cam_k = _cam.image_name
                        _old_sup = refined_masks.get(_cam_k, _deva)
                        if isinstance(_old_sup, torch.Tensor) and _old_sup.device.type == "cpu":
                            _old_sup = _old_sup.cuda()
                        _pkg = render(_cam, gaussians, pipe, background)
                        _feat16 = _pkg["semantic"]   # [d, H, W]
                        _depth  = _pkg["depth"]
                        _proj   = distiller.project(_feat16)  # [512, H, W]
                        _anch   = distiller.get_target_anchors(_old_sup)
                        _cons   = compute_gsfl_consistency(
                            _proj, _anch, _depth,
                            lambda_depth=getattr(opt, 'gsfl_lambda_depth', 0.1),
                        )
                        _refined = refine_pseudo_labels(
                            _proj, _old_sup, distiller.anchors, _cons,
                            confidence_threshold=_cur_thr,
                            accept_threshold=gsfl_accept_threshold,
                            margin_threshold=gsfl_margin_threshold,
                            disable_gate1=gsfl_disable_gate1,
                            disable_gate2=gsfl_disable_gate2,
                            disable_gate3=gsfl_disable_gate3,
                        )
                        refined_masks[_cam_k] = _refined.cpu()
                        _n_updated += 1
                    print(f"[GSFL Batch Refine] iter={iteration}: updated {_n_updated}/{len(masked_train_cameras)} cameras "
                          f"(refined_masks total: {len(refined_masks)})")


    progress_bar.close()
    total_elapsed_sec = time.perf_counter() - train_start_time
    peak_mem_mb = 0.0
    if torch.cuda.is_available():
        peak_mem_mb = torch.cuda.max_memory_allocated() / (1024.0 ** 2)

    stats = {
        "total_iterations": int(opt.iterations),
        "geometry_iters": int(getattr(opt, "geometry_iters", 30000)),
        "semantic_iters": int(opt.iterations - getattr(opt, "geometry_iters", 30000)),
        "semantic_feature_dim": int(getattr(opt, "semantic_feature_dim", 16)),
        "ablation_mode": str(getattr(opt, "ablation_mode", "full")),
        "total_elapsed_sec": float(total_elapsed_sec),
        "peak_gpu_mem_mb": float(peak_mem_mb),
    }
    os.makedirs(dataset.model_path, exist_ok=True)
    stats_path = os.path.join(dataset.model_path, "train_stats.json")
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)
    print(f"[Train Stats] saved to {stats_path}")
