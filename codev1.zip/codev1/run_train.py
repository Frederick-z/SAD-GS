"""
SAD-GS training launcher.
Usage:
    python run_train.py --source_path <scene> --model_path <out> [options]

Extra args not in OptimizationParams:
    --geometry_iters   int   iterations for Stage 1 (default: 30000)
    --semantic_feature_dim int semantic feature dimension for Gaussian attributes (default: 16)
    --lambda_sad       float SAD loss weight      (default: 0.1)
    --lambda_id_ce     float ID CE loss weight    (default: 0.0)
    --id_ce_temperature float CE logits temperature (default: 0.07)
    --deva_mask_dir    str   path to DEVA masks   (default: None)
"""
import sys
import os
import torch
from argparse import ArgumentParser
from arguments import ModelParams, OptimizationParams, PipelineParams
from train import training
from utils.general_utils import safe_state

if __name__ == "__main__":
    parser = ArgumentParser(description="SAD-GS Training")
    lp = ModelParams(parser)
    op = OptimizationParams(parser)
    pp = PipelineParams(parser)

    parser.add_argument('--ip', type=str, default="127.0.0.1")
    parser.add_argument('--port', type=int, default=12652)
    parser.add_argument('--debug_from', type=int, default=-1)
    parser.add_argument('--detect_anomaly', action='store_true', default=False)
    parser.add_argument("--test_iterations", nargs="+", type=int, default=[])
    parser.add_argument("--saving_iterations", nargs="+", type=int, default=[])
    parser.add_argument("--quiet", action="store_true")
    parser.add_argument("--checkpoint_iterations", nargs="+", type=int, default=[])
    parser.add_argument("--start_checkpoint", type=str, default=None)

    # SAD-GS extra params
    parser.add_argument("--geometry_iters", type=int, default=30000)
    parser.add_argument("--lambda_sad", type=float, default=0.1)
    parser.add_argument("--lambda_id_ce", type=float, default=0.0)
    parser.add_argument("--id_ce_temperature", type=float, default=0.07)
    parser.add_argument("--deva_mask_dir", type=str, default=None)
    parser.add_argument("--ablation_mode", type=str, default="full", choices=["full", "sad_only", "gsfl_only"],
                        help="Ablation mode: 'full' (SAD+GSFL), 'sad_only' (disable GSFL weighting), 'gsfl_only' (only GSFL consistency)")

                 
    parser.add_argument("--gsfl_warmup_iters", type=int, default=5000,
                        help="Stage-2 warmup steps before activating GSFL pseudo-label updates (default: 5000)")
    parser.add_argument("--gsfl_conf_threshold", type=float, default=0.5,
                        help="Initial adaptive confidence threshold, linearly increased during training (default: 0.5)")
    parser.add_argument("--gsfl_conf_end", type=float, default=0.65,
                        help="Final adaptive confidence threshold reached after the ramp (default: 0.65)")
    parser.add_argument("--gsfl_conf_ramp_iters", type=int, default=10000,
                        help="Number of steps for ramping the confidence threshold (default: 10000)")
    parser.add_argument("--gsfl_accept_threshold", type=float, default=0.6,
                        help="Cosine similarity threshold for accepting new labels (default: 0.6)")
    parser.add_argument("--gsfl_margin_threshold", type=float, default=0.05,
                        help="Gate 3 margin threshold: best anchor similarity must exceed runner-up by this value")
    parser.add_argument("--gsfl_disable_gate1", action="store_true", default=False,
                        help="Ablation: disable Gate 1 low-consistency filtering")
    parser.add_argument("--gsfl_disable_gate2", action="store_true", default=False,
                        help="Ablation: disable Gate 2 absolute similarity filtering")
    parser.add_argument("--gsfl_disable_gate3", action="store_true", default=False,
                        help="Ablation: disable Gate 3 margin filtering")
    parser.add_argument("--gsfl_lambda_depth", type=float, default=0.1,
                        help="Depth-gradient weight coefficient (default: 0.1)")
    parser.add_argument("--pseudo_label_update_interval", type=int, default=500,
                        help="Pseudo-label refinement interval in Stage-2 (default: 500)")
    parser.add_argument("--gsfl_enable_pseudo_refine", action="store_true", default=True,
                        help="Enable GSFL pseudo-label refinement (default: enabled)")
    parser.add_argument("--no_gsfl_pseudo_refine", dest="gsfl_enable_pseudo_refine",
                        action="store_false",
                        help="Disable GSFL pseudo-label refinement")
    parser.add_argument("--anchor_ema_momentum", type=float, default=0.99,
                        help="Anchor EMA momentum (default: 0.99)")
    parser.add_argument("--anchor_update_interval", type=int, default=100,
                        help="Anchor update interval in steps (default: 100)")
    parser.add_argument("--gsfl_enable_anchor_update", action="store_true", default=False,
                        help="Enable online GSFL anchor EMA updates (default: disabled)")
    parser.add_argument("--no_gsfl_anchor_update", dest="gsfl_enable_anchor_update",
                        action="store_false",
                        help="Disable online GSFL anchor updates")
    # E11: DEVA-guided safe anchor update
    parser.add_argument("--gsfl_enable_deva_anchor_update", action="store_true", default=False,
                        help="E11: enable DEVA-guided safe anchor updates")
    parser.add_argument("--no_gsfl_deva_anchor_update", dest="gsfl_enable_deva_anchor_update",
                        action="store_false",
                        help="Disable DEVA-guided anchor updates")
    parser.add_argument("--deva_anchor_update_interval", type=int, default=500,
                        help="DEVA-guided anchor update interval in steps (default: 500)")
    parser.add_argument("--deva_anchor_ema_momentum", type=float, default=0.999,
                        help="DEVA-guided anchor EMA momentum (default: 0.999)")
    parser.add_argument("--pseudo_label_batch_interval", type=int, default=2000,
                        help="Full-batch pseudo-label refresh interval; 0 disables it (default: 2000)")

    args = parser.parse_args(sys.argv[1:])
    args.saving_iterations.append(args.iterations)

    # Extract param groups
    lp_extracted = lp.extract(args)
    op_extracted = op.extract(args)

    # Attach extra SAD-GS params to op so train.py can read via getattr
    op_extracted.geometry_iters = args.geometry_iters
    op_extracted.semantic_feature_dim = args.semantic_feature_dim
    op_extracted.lambda_sad = args.lambda_sad
    op_extracted.lambda_id_ce = args.lambda_id_ce
    op_extracted.id_ce_temperature = args.id_ce_temperature
    op_extracted.ablation_mode = args.ablation_mode
    op_extracted.gsfl_warmup_iters      = args.gsfl_warmup_iters
    op_extracted.gsfl_conf_threshold    = args.gsfl_conf_threshold
    op_extracted.gsfl_conf_end          = args.gsfl_conf_end
    op_extracted.gsfl_conf_ramp_iters   = args.gsfl_conf_ramp_iters
    op_extracted.gsfl_accept_threshold  = args.gsfl_accept_threshold
    op_extracted.gsfl_margin_threshold  = args.gsfl_margin_threshold
    op_extracted.gsfl_disable_gate1     = args.gsfl_disable_gate1
    op_extracted.gsfl_disable_gate2     = args.gsfl_disable_gate2
    op_extracted.gsfl_disable_gate3     = args.gsfl_disable_gate3
    op_extracted.gsfl_lambda_depth      = args.gsfl_lambda_depth
    op_extracted.pseudo_label_update_interval = args.pseudo_label_update_interval
    op_extracted.gsfl_enable_pseudo_refine    = args.gsfl_enable_pseudo_refine
    op_extracted.anchor_ema_momentum    = args.anchor_ema_momentum
    op_extracted.anchor_update_interval = args.anchor_update_interval
    op_extracted.gsfl_enable_anchor_update = args.gsfl_enable_anchor_update
    op_extracted.gsfl_enable_deva_anchor_update = args.gsfl_enable_deva_anchor_update
    op_extracted.deva_anchor_update_interval = args.deva_anchor_update_interval
    op_extracted.deva_anchor_ema_momentum = args.deva_anchor_ema_momentum
    op_extracted.pseudo_label_batch_interval = args.pseudo_label_batch_interval

    # Attach deva_mask_dir to dataset params (camera_utils reads from args/dataset)
    lp_extracted.deva_mask_dir = args.deva_mask_dir

    print("Optimizing " + lp_extracted.model_path)

    safe_state(args.quiet)
    torch.autograd.set_detect_anomaly(args.detect_anomaly)

    training(
        lp_extracted, op_extracted, pp.extract(args),
        args.test_iterations,
        args.saving_iterations,
        args.checkpoint_iterations,
        args.start_checkpoint,
        args.debug_from,
    )
    print("Training done.")
