import torch
import torch.nn as nn
import torch.nn.functional as F
import os


def infer_feature_dim_from_projection_ckpt(checkpoint_path):
    """
    Infer the semantic feature dimension from the first projection layer.
    """
    checkpoint = torch.load(checkpoint_path, map_location="cpu")
    state_dict = checkpoint.get("model_state_dict", checkpoint)
    weight = state_dict["0.weight"]
    return int(weight.shape[1])


def build_distiller_from_ckpt(semantic_ckpt, anchor_path=None, device="cuda", clip_dim=512):
    """
    Build a SemanticDistiller whose input dimension matches the checkpoint.
    """
    feature_dim = infer_feature_dim_from_projection_ckpt(semantic_ckpt)
    distiller = SemanticDistiller(feature_dim=feature_dim, clip_dim=clip_dim).to(device)
    if anchor_path is not None:
        distiller.load_anchors(anchor_path)
    distiller.load_projection_layer(semantic_ckpt)
    distiller.projection.eval()
    return distiller

class SemanticDistiller(nn.Module):
       
                                       
                  
       
    
    def __init__(self, feature_dim=16, clip_dim=512, base_lr=0.001):
        super().__init__()
        self.feature_dim = feature_dim
        self.clip_dim = clip_dim
        self.base_lr = base_lr
        self.has_anchors = False
        self.anchors = None
        self.use_sparse_anchor_ids = False
        self.valid_anchor_ids = []
        self.valid_anchor_ids_t = None
        self.anchor_dense_to_compact = None
        
                                    
        self.projection = nn.Sequential(
            nn.Linear(feature_dim, 128),
            nn.ReLU(),
            nn.Linear(128, clip_dim)
        )
        self.optimizer = torch.optim.Adam(self.projection.parameters(), lr=base_lr)

    def load_anchors(self, path):
           
                  
        
             
                                                    
                                                                             
           
        data = torch.load(path)
        self.use_sparse_anchor_ids = False

                     
        if isinstance(data, dict):
                     
            max_id = max(data.keys()) + 1
            anchors_tensor = torch.zeros((max_id, self.clip_dim), device='cuda')
            self.valid_anchor_ids = sorted(int(track_id) for track_id in data.keys())
            self.use_sparse_anchor_ids = (
                len(self.valid_anchor_ids) != max_id
                or self.valid_anchor_ids != list(range(max_id))
            )
            for track_id, anchor_vec in data.items():
                anchors_tensor[track_id] = anchor_vec.cuda() if not anchor_vec.is_cuda else anchor_vec
            self.anchors = anchors_tensor
        else:
            self.anchors = data.cuda() if not data.is_cuda else data
            self.valid_anchor_ids = list(range(self.anchors.shape[0]))

        if self.use_sparse_anchor_ids:
            self.valid_anchor_ids_t = torch.tensor(self.valid_anchor_ids, device='cuda', dtype=torch.long)
            self.anchor_dense_to_compact = torch.full(
                (self.anchors.shape[0],), -1, device='cuda', dtype=torch.long
            )
            self.anchor_dense_to_compact[self.valid_anchor_ids_t] = torch.arange(
                len(self.valid_anchor_ids), device='cuda', dtype=torch.long
            )
        else:
            self.valid_anchor_ids_t = torch.arange(self.anchors.shape[0], device='cuda', dtype=torch.long)
            self.anchor_dense_to_compact = torch.arange(self.anchors.shape[0], device='cuda', dtype=torch.long)

        self.has_anchors = True
        print(
            f"Loaded semantic anchors: shape {self.anchors.shape}, "
            f"valid_ids={len(self.valid_anchor_ids)}, "
            f"sparse_mode={self.use_sparse_anchor_ids}"
        )

    def get_valid_anchor_ids_tensor(self):
        return self.valid_anchor_ids_t

    def get_valid_anchors(self):
        return self.anchors[self.valid_anchor_ids_t]

    def project(self, feat_16d):
           
                                 
        
             
                                                      
            
                
                                            
           
        C, H, W = feat_16d.shape
        feat_flat = feat_16d.permute(1, 2, 0).reshape(-1, C)  # [H*W, 16]
        projected = self.projection(feat_flat)                 # [H*W, 512]
        return projected.reshape(H, W, self.clip_dim).permute(2, 0, 1)  # [512, H, W]

    def get_target_anchors(self, deva_mask):
           
                        
        
             
                                                                          
            
                
                                          
           
        H, W = deva_mask.shape
        ids = deva_mask.flatten().long()  # [H*W]
        
                                                                
        ids = ids.clamp(0, self.anchors.shape[0] - 1)
        
              
        target = self.anchors[ids]  # [H*W, 512]
        return target.reshape(H, W, self.clip_dim).permute(2, 0, 1)  # [512, H, W]

    def compute_distillation_loss(self, pred, target, weight=None):
           
                                                  

                                                                                             
                                         
        
             
                                                    
                                                   
                                                                      
            
                
                                   
           
                    
        l2_loss = torch.norm(pred - target, dim=0)  # [H, W]
        
                         
        cos_sim = F.cosine_similarity(pred, target, dim=0)  # [H, W]
        cos_loss = 1.0 - cos_sim
        
                 
        combined_loss = l2_loss + 0.5 * cos_loss  # [H, W]
        
                             
        if weight is not None:
            combined_loss = combined_loss * weight
        
                
        return combined_loss.mean()

    def update_learning_rate(self, iteration, warmup_iters=5000, max_iters=50000):
           
                 
        
           
                                
                                                                 
        
             
                                   
                                    
                                
           
        if iteration > warmup_iters:
            decay_factor = 0.1 ** ((iteration - warmup_iters) / max_iters)
            lr = self.base_lr * max(decay_factor, 0.0001)           
        else:
            lr = self.base_lr
        
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = lr

    def save_projection_layer(self, save_dir, iteration):
           
                     
        
             
                                
                                   
           
        os.makedirs(save_dir, exist_ok=True)
        checkpoint_path = os.path.join(save_dir, f"semantic_distiller_{iteration}.pth")
        
        torch.save({
            'iteration': iteration,
            'model_state_dict': self.projection.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
        }, checkpoint_path)
        print(f"Saved projection layer checkpoint: {checkpoint_path}")

    def load_projection_layer(self, checkpoint_path):
           
                     
        
             
                                                  
            
                
                         
           
        checkpoint = torch.load(checkpoint_path)
        self.projection.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        iteration = checkpoint.get('iteration', 0)
        print(f"Loaded projection layer from {checkpoint_path} (iteration {iteration})")
        return iteration


def compute_gsfl_consistency(
    projected_feat,
    target_anchors,
    depth,
    lambda_depth=0.1,
    semantic_floor=0.2,
):
       
                              
    
         
                                                   
    
         
                                                          
                                                       
                                                      
                                      
        
            
                                            
       
    
                
    semantic_sim = F.cosine_similarity(projected_feat, target_anchors, dim=0)  # [H, W]
    # Keep a non-zero floor to avoid SAD gradients collapsing when cosine is mostly negative.
    semantic_sim = (semantic_sim + 1.0) * 0.5  # map [-1,1] -> [0,1]
    semantic_sim = torch.clamp(semantic_sim, min=semantic_floor, max=1.0)
    
                
    if len(depth.shape) == 3:
        depth = depth.squeeze(0)  # [H, W]
    
                     
                              
    depth_grad_x = torch.abs(depth[:, :-1] - depth[:, 1:])  # [H, W-1]
    depth_grad_y = torch.abs(depth[:-1, :] - depth[1:, :])  # [H-1, W]
    
                      
    depth_grad_x_padded = F.pad(depth_grad_x, (0, 1, 0, 0), mode='constant', value=0)  # [H, W]
    depth_grad_y_padded = F.pad(depth_grad_y, (0, 0, 0, 1), mode='constant', value=0)  # [H, W]
    depth_grad = depth_grad_x_padded + depth_grad_y_padded  # [H, W]
    
                   
                     
                      
    edge_weight = torch.exp(-lambda_depth * depth_grad)  # [H, W]
    
                      
    consistency = semantic_sim * edge_weight  # [H, W]
    
    return consistency


def refine_pseudo_labels(
    projected_feat: torch.Tensor,      # [512, H, W]  detached, no grad
    current_mask: torch.Tensor,        # [H, W] int — current supervision mask
    anchors: torch.Tensor,             # [num_ids, 512]
    consistency_score: torch.Tensor,   # [H, W] in [0, 1]
    valid_ids: torch.Tensor | None = None,
    confidence_threshold: float = 0.5,
    accept_threshold: float = 0.6,
    min_low_conf_ratio: float = 0.01,
    margin_threshold: float = 0.05,
    disable_gate1: bool = False,
    disable_gate2: bool = False,
    disable_gate3: bool = False,
) -> torch.Tensor:
       
                                          

                                 
                                                           
                                                 
                                                                        

                                                     
                                             
                                        

            
                                                            
       
    H, W = current_mask.shape
    refined_mask = current_mask.clone()

    if disable_gate1:
        low_conf = torch.ones_like(current_mask, dtype=torch.bool)
    else:
        low_conf = consistency_score < confidence_threshold   # [H, W]
    low_conf_flat = low_conf.reshape(-1)                  # [H*W]

                             
    low_ratio = low_conf_flat.float().mean().item()
    if low_ratio < min_low_conf_ratio or not low_conf_flat.any():
        return refined_mask

                
    feat_flat = projected_feat.permute(1, 2, 0).reshape(-1, projected_feat.shape[0])  # [H*W, 512]
    low_feat = feat_flat[low_conf_flat]  # [N_low, 512]

    if valid_ids is None:
        valid_ids = torch.arange(1, anchors.shape[0], device=anchors.device, dtype=torch.long)
    else:
        valid_ids = valid_ids.to(device=anchors.device, dtype=torch.long)
        valid_ids = valid_ids[valid_ids > 0]
    if valid_ids.numel() == 0:
        return refined_mask

                   
    low_feat_norm = F.normalize(low_feat, dim=1)          # [N_low, 512]
    anchors_norm  = F.normalize(anchors[valid_ids], dim=1)   # [num_valid, 512]
    sims    = low_feat_norm @ anchors_norm.T                 # [N_low, num_valid]
    best_sim, new_idx = sims.max(dim=1)                      # [N_low], [N_low]
    new_ids = valid_ids[new_idx]

                                           
                              
    if disable_gate2:
        accepted = torch.ones_like(best_sim, dtype=torch.bool)
    else:
        accepted = best_sim >= accept_threshold               # [N_low] bool

                                             
                               
    if (not disable_gate3) and sims.shape[1] > 1 and margin_threshold > 0.0:
        top2_sims, _ = sims.topk(2, dim=1)               # [N_low, 2]
        margin = top2_sims[:, 0] - top2_sims[:, 1]       # [N_low]
        accepted = accepted & (margin >= margin_threshold)

                         
    refined_flat = refined_mask.reshape(-1)
    low_conf_indices = low_conf_flat.nonzero(as_tuple=False).squeeze(1)  # [N_low]
    accepted_indices = low_conf_indices[accepted]                         # [N_accept]
    refined_flat[accepted_indices] = new_ids[accepted].to(refined_flat.dtype)

    return refined_flat.reshape(H, W)


def update_anchors_online(
    anchors: torch.Tensor,            # [num_ids, 512]  current anchors
    projected_feat: torch.Tensor,     # [512, H, W]  detached
    mask: torch.Tensor,               # [H, W] int
    consistency_score: torch.Tensor,  # [H, W]
    valid_ids: torch.Tensor | None = None,
    momentum: float = 0.99,
    confidence_threshold: float = 0.6,
    min_pixels: int = 10,
) -> torch.Tensor:
       
                                           

                              
                                                       

                                                               
                              

            
                                      
       
    feat_flat = projected_feat.permute(1, 2, 0).reshape(-1, projected_feat.shape[0])  # [H*W, 512]
    mask_flat = mask.reshape(-1).long()           # [H*W]
    conf_flat = consistency_score.reshape(-1)     # [H*W]

    new_anchors = anchors.clone()

    if valid_ids is None:
        valid_ids = torch.arange(1, anchors.shape[0], device=anchors.device, dtype=torch.long)
    else:
        valid_ids = valid_ids.to(device=anchors.device, dtype=torch.long)
        valid_ids = valid_ids[valid_ids > 0]

    for obj_id_t in valid_ids:
        obj_id = int(obj_id_t.item())
        obj_high_conf = (mask_flat == obj_id) & (conf_flat >= confidence_threshold)
        if obj_high_conf.sum().item() < min_pixels:
            continue

        obj_feat      = feat_flat[obj_high_conf]                  # [N, 512]
        obj_feat_mean = F.normalize(obj_feat.mean(dim=0), dim=0)  # [512]

                                                 
        new_anchors[obj_id] = momentum * anchors[obj_id] + (1.0 - momentum) * obj_feat_mean
        new_anchors[obj_id] = F.normalize(new_anchors[obj_id], dim=0)

    return new_anchors


def update_anchors_from_deva(
    anchors: torch.Tensor,          # [num_ids, 512]  current anchors
    projected_feat: torch.Tensor,   # [512, H, W]  detached
    deva_mask: torch.Tensor,        # [H, W] int  — external GT pseudo-labels (DEVA)
    valid_ids: torch.Tensor | None = None,
    momentum: float = 0.999,
    min_pixels: int = 10,
) -> torch.Tensor:
       
                           

                                  
                                             
                            
                                           

                          
                                       

            
                                      
       
    import torch.nn.functional as F_local

    feat_flat = projected_feat.permute(1, 2, 0).reshape(-1, projected_feat.shape[0])  # [H*W, 512]
    deva_flat = deva_mask.reshape(-1).long()  # [H*W]

    new_anchors = anchors.clone()

    if valid_ids is None:
        valid_ids = torch.arange(1, anchors.shape[0], device=anchors.device, dtype=torch.long)
    else:
        valid_ids = valid_ids.to(device=anchors.device, dtype=torch.long)
        valid_ids = valid_ids[valid_ids > 0]

    for obj_id_t in valid_ids:
        obj_id = int(obj_id_t.item())
        obj_pix = (deva_flat == obj_id)
        if obj_pix.sum().item() < min_pixels:
            continue

        obj_feat      = feat_flat[obj_pix]                          # [N, 512]
        obj_feat_mean = F_local.normalize(obj_feat.mean(dim=0), dim=0)  # [512]

        new_anchors[obj_id] = momentum * anchors[obj_id] + (1.0 - momentum) * obj_feat_mean
        new_anchors[obj_id] = F_local.normalize(new_anchors[obj_id], dim=0)

    return new_anchors
