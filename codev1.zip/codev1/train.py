import torch
import os
import sys
import random
import json
import time
from random import randint
from tqdm import tqdm
from gaussian_renderer import render
from scene import Scene
from scene.gaussian_model import GaussianModel
from utils.loss_utils import l1_loss, ssim
from utils.semantic_utils import (
    SemanticDistiller, compute_gsfl_consistency,
    refine_pseudo_labels, update_anchors_online, update_anchors_from_deva,
)
import torch.nn.functional as F

def training(dataset, opt, pipe, testing_iterations, saving_iterations, checkpoint_iterations, checkpoint, debug_from):
       
                 
                                                                
                                                               
       
    first_iter = 0
    train_start_time = time.perf_counter()
    stage = "geometric"        
    semantic_distiller_checkpoint = None  # Stage 2 checkpoint
    
    gaussians = GaussianModel(dataset.sh_degree)
    scene = Scene(dataset, gaussians)
    
                    
    opt.include_feature = False                   
    gaussians.training_setup(opt)
    
    if checkpoint:
        (model_params, first_iter) = torch.load(checkpoint, weights_only=False)
        gaussians.restore(model_params, opt)

    bg_color = [1, 1, 1] if dataset.white_background else [0, 0, 0]
    background = torch.tensor(bg_color, dtype=torch.float32, device="cuda")

                               
    distiller = None
    stage_2_start_iter = getattr(opt, 'geometry_iters', 30000)
    semantic_feature_dim = int(getattr(opt, "semantic_feature_dim", 16))
    if semantic_feature_dim > 34:
        raise ValueError(
            f"semantic_feature_dim={semantic_feature_dim} exceeds the current rasterizer limit (34)."
        )
    lambda_id_ce = getattr(opt, 'lambda_id_ce', 0.0)
    id_ce_temperature = max(getattr(opt, 'id_ce_temperature', 0.07), 1e-6)
    masked_train_cameras = [cam for cam in scene.getTrainCameras() if cam.deva_mask is not None]
    print(f"Masked train cameras: {len(masked_train_cameras)} / {len(scene.getTrainCameras())}")
    
            
    ablation_mode = getattr(opt, 'ablation_mode', 'full')
    print(f"Ablation mode: {ablation_mode}")
    assert ablation_mode in ['full', 'sad_only', 'gsfl_only'], f"Invalid ablation_mode: {ablation_mode}"

                              
                                                                  
    refined_masks: dict = {}
    gsfl_warmup_iters    = getattr(opt, 'gsfl_warmup_iters', 5000)
    gsfl_conf_start      = getattr(opt, 'gsfl_conf_threshold', 0.5)
    gsfl_conf_end        = getattr(opt, 'gsfl_conf_end', 0.65)
    gsfl_conf_ramp_iters = getattr(opt, 'gsfl_conf_ramp_iters', 10000)
    gsfl_accept_threshold        = getattr(opt, 'gsfl_accept_threshold', 0.6)
    gsfl_margin_threshold        = getattr(opt, 'gsfl_margin_threshold', 0.05)
    gsfl_disable_gate1           = getattr(opt, 'gsfl_disable_gate1', False)
    gsfl_disable_gate2           = getattr(opt, 'gsfl_disable_gate2', False)
    gsfl_disable_gate3           = getattr(opt, 'gsfl_disable_gate3', False)
    anchor_ema_momentum          = getattr(opt, 'anchor_ema_momentum', 0.99)
    anchor_update_interval       = getattr(opt, 'anchor_update_interval', 100)
                                           
    gsfl_enable_anchor_update    = getattr(opt, 'gsfl_enable_anchor_update', False)
                                                       
    gsfl_enable_deva_anchor_update  = getattr(opt, 'gsfl_enable_deva_anchor_update', False)
    deva_anchor_update_interval     = getattr(opt, 'deva_anchor_update_interval', 500)
    deva_anchor_ema_momentum        = getattr(opt, 'deva_anchor_ema_momentum', 0.999)
                                     
    pseudo_label_update_interval = getattr(opt, 'pseudo_label_update_interval', 500)
                                   
    gsfl_enable_pseudo_refine    = getattr(opt, 'gsfl_enable_pseudo_refine', True)
                                             
                                                      
    pseudo_label_batch_interval  = getattr(opt, 'pseudo_label_batch_interval', 2000)


    progress_bar = tqdm(range(first_iter, opt.iterations), desc="Training progress")
    first_iter += 1
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()

    for iteration in range(first_iter, opt.iterations + 1):
                        
        if iteration == stage_2_start_iter + 1 and stage == "geometric":
            stage = "semantic"
            print(f"\n[Epoch {iteration}] Switching to Stage 2: Semantic Distillation")
            
                    
            opt.include_feature = True
            gaussians.training_setup(opt)
            
                      
            distiller = SemanticDistiller(feature_dim=semantic_feature_dim, clip_dim=512).cuda()
            anchor_path = os.path.join(dataset.source_path, "semantic_anchors.pt")
            if os.path.exists(anchor_path):
                distiller.load_anchors(anchor_path)
                print(f"Loaded semantic anchors from {anchor_path}")
            else:
                print(f"[Warning] No semantic anchors found at {anchor_path}")
        
                               
        if stage == "geometric":
            gaussians.update_learning_rate(iteration)
            
            if iteration % 1000 == 0:
                gaussians.oneupSHdegree()

                    
            viewpoint_cam = random.choice(scene.getTrainCameras())

                
            render_pkg = render(viewpoint_cam, gaussians, pipe, background)
            image = render_pkg["render"]

                               
            gt_image = viewpoint_cam.original_image.cuda()
            Ll1 = l1_loss(image, gt_image)
            loss = (1.0 - opt.lambda_dssim) * Ll1 + opt.lambda_dssim * (1.0 - ssim(image, gt_image))

                  
            loss.backward()
            
            with torch.no_grad():
                if iteration % 10 == 0:
                    progress_bar.set_postfix({"Loss": f"{loss.item():.4f}", "Stage": "Geometric"})
                    progress_bar.update(10)

                gaussians.optimizer.step()
                gaussians.optimizer.zero_grad(set_to_none=True)

                        
                if iteration < opt.densify_until_iter:
                    gaussians.add_densification_stats(render_pkg["viewspace_points"], render_pkg["visibility_filter"])
                    if iteration > opt.densify_from_iter and iteration % opt.densification_interval == 0:
                        gaussians.densify_and_prune(opt.densify_grad_threshold, 0.005, scene.cameras_extent, None)

                               
                if iteration in saving_iterations:
                    print(f"[Stage 1] Saving checkpoint at iteration {iteration}")
                    scene.save(iteration)

                               
        else:
            assert distiller is not None, "Distiller not initialized for Stage 2"
            
            gaussians.update_learning_rate(iteration)
            distiller.update_learning_rate(iteration, warmup_iters=stage_2_start_iter)

                                              
            if masked_train_cameras:
                viewpoint_cam = random.choice(masked_train_cameras)
            else:
                viewpoint_cam = random.choice(scene.getTrainCameras())

                
            render_pkg = render(viewpoint_cam, gaussians, pipe, background)
            image = render_pkg["render"]
            depth = render_pkg["depth"]
            semantic_feat_16d = render_pkg["semantic"]  # [d, H, W]

                                     
            gt_image = viewpoint_cam.original_image.cuda()
            Ll1 = l1_loss(image, gt_image)
            loss_rgb = (1.0 - opt.lambda_dssim) * Ll1 + opt.lambda_dssim * (1.0 - ssim(image, gt_image))
            loss = loss_rgb

                                   
            loss_sad = None
            loss_gsfl = None
            loss_id_ce = None
            consistency_mean_val  = 0.0                      
            label_change_rate_val = 0.0
            anchor_delta_val = 0.0
            deva_anchor_delta_val = 0.0
            anchor_update_applied = 0
            deva_anchor_update_applied = 0
            if distiller.has_anchors and viewpoint_cam.deva_mask is not None:
                deva_mask = viewpoint_cam.deva_mask.cuda()                       
                cam_key   = viewpoint_cam.image_name

                                                                              
                             
                                                                    
                                                               
                                                              
                if ablation_mode == "full" and cam_key in refined_masks:
                    supervision_mask = refined_masks[cam_key].cuda()
                else:
                    supervision_mask = deva_mask                               
                
                                   
                projected_feat_512d = distiller.project(semantic_feat_16d)  # [512, H, W]
                
                                                 
                target_anchors = distiller.get_target_anchors(supervision_mask)  # [512, H, W]
                valid_anchor_ids_t = distiller.get_valid_anchor_ids_tensor()
                
                                                                  
                                                                        
                                                                         
                                                                     
                                          
                consistency_mean_val  = 0.0
                label_change_rate_val = 0.0
                if ablation_mode == "full":
                                 
                                                         
                                                          
                    loss_sad = distiller.compute_distillation_loss(projected_feat_512d, target_anchors)
                    loss += getattr(opt, 'lambda_sad', 0.1) * loss_sad

                                                        
                    gsfl_active_iter = stage_2_start_iter + gsfl_warmup_iters
                    if iteration > gsfl_active_iter:
                        with torch.no_grad():
                            stage2_elapsed = iteration - stage_2_start_iter

                                                             
                            consistency_score = compute_gsfl_consistency(
                                projected_feat_512d.detach(), target_anchors.detach(), depth,
                                lambda_depth=getattr(opt, 'gsfl_lambda_depth', 0.1),
                            )
                            consistency_mean_val = consistency_score.mean().item()

                                                              
                            ramp_progress = min(
                                1.0,
                                (iteration - gsfl_active_iter) / max(gsfl_conf_ramp_iters, 1)
                            )
                            current_conf_threshold = (
                                gsfl_conf_start + (gsfl_conf_end - gsfl_conf_start) * ramp_progress
                            )

                                                                                 
                                                                      
                            if (gsfl_enable_pseudo_refine
                                    and stage2_elapsed % pseudo_label_update_interval == 0):
                                old_mask = supervision_mask
                                refined = refine_pseudo_labels(
                                    projected_feat_512d.detach(),
                                    supervision_mask,
                                    distiller.anchors,
                                    consistency_score,
                                    valid_ids=valid_anchor_ids_t,
                                    confidence_threshold=current_conf_threshold,
                                    accept_threshold=gsfl_accept_threshold,
                                    margin_threshold=gsfl_margin_threshold,
                                    disable_gate1=gsfl_disable_gate1,
                                    disable_gate2=gsfl_disable_gate2,
                                    disable_gate3=gsfl_disable_gate3,
                                )
                                refined_masks[cam_key] = refined.cpu()
                                label_change_rate_val = (refined.cpu() != old_mask.cpu()).float().mean().item()

                                                                                          
                            if gsfl_enable_anchor_update and stage2_elapsed % anchor_update_interval == 0:
                                prev_anchors = distiller.anchors.clone()
                                distiller.anchors = update_anchors_online(
                                    distiller.anchors,
                                    projected_feat_512d.detach(),
                                    supervision_mask,
                                    consistency_score,
                                    valid_ids=valid_anchor_ids_t,
                                    momentum=anchor_ema_momentum,
                                    confidence_threshold=min(current_conf_threshold + 0.1, 0.9),
                                )
                                anchor_delta_val = (distiller.anchors - prev_anchors).norm(dim=1).mean().item()
                                anchor_update_applied = 1

                                                                                            
                                                            
                            if gsfl_enable_deva_anchor_update and stage2_elapsed % deva_anchor_update_interval == 0:
                                deva_mask_for_anchor = viewpoint_cam.deva_mask
                                if deva_mask_for_anchor is not None:
                                    prev_anchors = distiller.anchors.clone()
                                    distiller.anchors = update_anchors_from_deva(
                                        distiller.anchors,
                                        projected_feat_512d.detach(),
                                        deva_mask_for_anchor,
                                        valid_ids=valid_anchor_ids_t,
                                        momentum=deva_anchor_ema_momentum,
                                    )
                                    deva_anchor_delta_val = (distiller.anchors - prev_anchors).norm(dim=1).mean().item()
                                    deva_anchor_update_applied = 1

                elif ablation_mode == "sad_only":
                                                                    
                                                             
                                                                        
                                                           
                    loss_sad = distiller.compute_distillation_loss(projected_feat_512d, target_anchors)
                    loss += getattr(opt, 'lambda_sad', 0.1) * loss_sad

                elif ablation_mode == "gsfl_only":
                                                                            
                                                             
                                                      
                    consistency_score = compute_gsfl_consistency(
                        projected_feat_512d, target_anchors, depth
                    )
                    lambda_gsfl = getattr(opt, 'lambda_sad', 0.1)
                    loss_gsfl = (1.0 - consistency_score).mean()
                    loss += lambda_gsfl * loss_gsfl

                                                          
                if lambda_id_ce > 0.0:
                    feat = projected_feat_512d.permute(1, 2, 0).reshape(-1, projected_feat_512d.shape[0])
                    feat = feat / feat.norm(dim=1, keepdim=True).clamp(min=1e-8)

                    anchors = distiller.anchors
                    anchors = anchors / anchors.norm(dim=1, keepdim=True).clamp(min=1e-8)
                    if distiller.use_sparse_anchor_ids:
                        valid_anchor_ids_t = distiller.get_valid_anchor_ids_tensor()
                        anchors_valid = anchors[valid_anchor_ids_t]
                        logits = (feat @ anchors_valid.T) / id_ce_temperature
                    else:
                        logits = (feat @ anchors.T) / id_ce_temperature

                                                           
                    target_ids = supervision_mask.reshape(-1).long()
                    if distiller.use_sparse_anchor_ids:
                        compact_ids = distiller.anchor_dense_to_compact[target_ids.clamp(0, anchors.shape[0] - 1)]
                        valid = compact_ids >= 0
                    else:
                        compact_ids = target_ids
                        valid = (target_ids > 0) & (target_ids < anchors.shape[0])
                    if torch.any(valid):
                        loss_id_ce = F.cross_entropy(logits[valid], compact_ids[valid])
                        loss += lambda_id_ce * loss_id_ce

                if iteration % 100 == 0:
                    with torch.no_grad():
                        id_ce_str   = f", id_ce={loss_id_ce.item():.4f}" if loss_id_ce is not None else ""
                        sad_str     = f"sad={loss_sad.item():.4f}" if loss_sad is not None else ""
                        gsfl_str    = f"gsfl={loss_gsfl.item():.4f}" if loss_gsfl is not None else ""
                        if ablation_mode == "full":
                            gsfl_active_iter = stage_2_start_iter + gsfl_warmup_iters
                            gsfl_status = "active" if iteration > gsfl_active_iter else f"warmup({gsfl_active_iter - iteration})"
                                              
                            ramp_p = min(1.0, max(0.0, (iteration - gsfl_active_iter) / max(gsfl_conf_ramp_iters, 1)))
                            cur_thr = gsfl_conf_start + (gsfl_conf_end - gsfl_conf_start) * ramp_p
                            extra = (
                                f", gsfl={gsfl_status}"
                                f", thr={cur_thr:.3f}"
                                f", consistency={consistency_mean_val:.4f}"
                                f", label_chg={label_change_rate_val:.3f}"
                                f", refined_cams={len(refined_masks)}/{len(masked_train_cameras)}"
                                f", anchor_delta={anchor_delta_val:.6f}"
                                f", deva_anchor_delta={deva_anchor_delta_val:.6f}"
                                f", anchor_upd={anchor_update_applied}"
                                f", deva_anchor_upd={deva_anchor_update_applied}"
                            )
                        else:
                            extra = f", mode={ablation_mode}"
                        print(
                            f"[GSFL Debug][iter {iteration}] "
                            f"{sad_str} {gsfl_str}{id_ce_str}{extra}"
                        )

                  
            loss.backward()
            
            with torch.no_grad():
                if iteration % 10 == 0:
                    sad_str  = f"{loss_sad.item():.4f}"  if loss_sad  is not None else "N/A"
                    gsfl_str = f"{loss_gsfl.item():.4f}" if loss_gsfl is not None else "N/A"
                    id_ce_str = f"{loss_id_ce.item():.4f}" if loss_id_ce is not None else "N/A"
                    postfix = {
                        "RGB": f"{loss_rgb.item():.4f}",
                        "SAD": sad_str,
                        "IDCE": id_ce_str,
                        "Stage": "Semantic",
                    }
                    if ablation_mode == "full":
                        postfix["C̄"] = f"{consistency_mean_val:.3f}"          
                        postfix["ΔL"] = f"{label_change_rate_val:.3f}"         
                    else:
                        postfix["GSFL"] = gsfl_str
                    progress_bar.set_postfix(postfix)
                    progress_bar.update(10)

                       
                gaussians.optimizer.step()
                gaussians.optimizer.zero_grad(set_to_none=True)
                distiller.optimizer.step()
                distiller.optimizer.zero_grad(set_to_none=True)

                               
                if iteration in saving_iterations:
                    print(f"[Stage 2] Saving checkpoint at iteration {iteration}")
                    scene.save(iteration)
                    checkpoint_dir = os.path.join(dataset.model_path, "semantic_checkpoints")
                    distiller.save_projection_layer(checkpoint_dir, iteration)

                                                                    
                                                                     
                                                                             
                _gsfl_active = stage_2_start_iter + gsfl_warmup_iters
                _stage2_elapsed_now = iteration - stage_2_start_iter
                if (ablation_mode == "full"
                        and gsfl_enable_pseudo_refine
                        and pseudo_label_batch_interval > 0
                        and iteration > _gsfl_active
                        and _stage2_elapsed_now > 0
                        and _stage2_elapsed_now % pseudo_label_batch_interval == 0):
                                                
                    _ramp = min(1.0, (iteration - _gsfl_active) / max(gsfl_conf_ramp_iters, 1))
                    _cur_thr = gsfl_conf_start + (gsfl_conf_end - gsfl_conf_start) * _ramp
                    _n_updated = 0
                    for _cam in masked_train_cameras:
                        if _cam.deva_mask is None:
                            continue
                        _deva = _cam.deva_mask.cuda()
                        _cam_k = _cam.image_name
                        _old_sup = refined_masks.get(_cam_k, _deva)
                        if isinstance(_old_sup, torch.Tensor) and _old_sup.device.type == "cpu":
                            _old_sup = _old_sup.cuda()
                        _pkg = render(_cam, gaussians, pipe, background)
                        _feat16 = _pkg["semantic"]   # [d, H, W]
                        _depth  = _pkg["depth"]
                        _proj   = distiller.project(_feat16)  # [512, H, W]
                        _anch   = distiller.get_target_anchors(_old_sup)
                        _cons   = compute_gsfl_consistency(
                            _proj, _anch, _depth,
                            lambda_depth=getattr(opt, 'gsfl_lambda_depth', 0.1),
                        )
                        _refined = refine_pseudo_labels(
                            _proj, _old_sup, distiller.anchors, _cons,
                            confidence_threshold=_cur_thr,
                            accept_threshold=gsfl_accept_threshold,
                            margin_threshold=gsfl_margin_threshold,
                            disable_gate1=gsfl_disable_gate1,
                            disable_gate2=gsfl_disable_gate2,
                            disable_gate3=gsfl_disable_gate3,
                        )
                        refined_masks[_cam_k] = _refined.cpu()
                        _n_updated += 1
                    print(f"[GSFL Batch Refine] iter={iteration}: updated {_n_updated}/{len(masked_train_cameras)} cameras "
                          f"(refined_masks total: {len(refined_masks)})")


    progress_bar.close()
    total_elapsed_sec = time.perf_counter() - train_start_time
    peak_mem_mb = 0.0
    if torch.cuda.is_available():
        peak_mem_mb = torch.cuda.max_memory_allocated() / (1024.0 ** 2)

    stats = {
        "total_iterations": int(opt.iterations),
        "geometry_iters": int(getattr(opt, "geometry_iters", 30000)),
        "semantic_iters": int(opt.iterations - getattr(opt, "geometry_iters", 30000)),
        "semantic_feature_dim": int(getattr(opt, "semantic_feature_dim", 16)),
        "ablation_mode": str(getattr(opt, "ablation_mode", "full")),
        "total_elapsed_sec": float(total_elapsed_sec),
        "peak_gpu_mem_mb": float(peak_mem_mb),
    }
    os.makedirs(dataset.model_path, exist_ok=True)
    stats_path = os.path.join(dataset.model_path, "train_stats.json")
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)
    print(f"[Train Stats] saved to {stats_path}")
